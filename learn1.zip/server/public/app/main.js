System.register(['angular2/core', 'angular2/platform/browser', 'angular2/http', 'angular2/router', 'angular2/platform/common', './app', './services/session', './services/tutor', './services/config', 'angular2-jwt'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var core_1, browser_1, http_1, router_1, common_1, app_1, session_1, tutor_1, config_1, angular2_jwt_1, core_2;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
                core_2 = core_1_1;
            },
            function (browser_1_1) {
                browser_1 = browser_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (app_1_1) {
                app_1 = app_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (tutor_1_1) {
                tutor_1 = tutor_1_1;
            },
            function (config_1_1) {
                config_1 = config_1_1;
            },
            function (angular2_jwt_1_1) {
                angular2_jwt_1 = angular2_jwt_1_1;
            }],
        execute: function() {
            // import {IDLE_PROVIDERS} from 'ng2-idle/core';
            core_2.enableProdMode();
            browser_1.bootstrap(app_1.AppComponent, [
                session_1.Session,
                tutor_1.TutorService,
                config_1.AppConfig,
                http_1.HTTP_PROVIDERS,
                router_1.ROUTER_PROVIDERS,
                // IDLE_PROVIDERS,
                core_1.provide(common_1.LocationStrategy, { useClass: common_1.HashLocationStrategy }),
                core_1.provide(angular2_jwt_1.AuthHttp, {
                    useFactory: function (http) {
                        return new angular2_jwt_1.AuthHttp(new angular2_jwt_1.AuthConfig(), http);
                    },
                    deps: [http_1.Http]
                })
            ])
                .catch(function (err) { return console.error(err); });
        }
    }
});
//# sourceMappingURL=main.js.map