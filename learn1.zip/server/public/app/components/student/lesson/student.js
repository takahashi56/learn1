System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/student'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, student_1;
    var StudentLesson;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (student_1_1) {
                student_1 = student_1_1;
            }],
        execute: function() {
            StudentLesson = (function () {
                function StudentLesson(_session, _studentService, _router) {
                    var _this = this;
                    this._session = _session;
                    this._studentService = _studentService;
                    this._router = _router;
                    this.lessonList = [];
                    if (this._session.getCurrentId() == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        this.course = JSON.parse(this._session.getItem('selectedCourse'));
                        this.student_id = this._session.getItem('MainStudentId');
                        var self = this;
                        this.htmlstring = "";
                        this._studentService.getLessonListById(this.course.course_id, this.student_id).subscribe(function (res) {
                            _this.lessonList = res;
                            _this._session.setItem('lessonList', JSON.stringify(res));
                            _this.lessonList.forEach(function (lesson) {
                                _this._session.setItem(lesson.lesson_id, JSON.stringify({
                                    total: lesson.count,
                                    right: 0,
                                    score: lesson.score
                                }));
                            });
                        });
                    }
                    // this._studentService.getScoreListByCourse({course_id: this.course.course_id, student_id: this.student_id}).subscribe((res)=>{
                    // 	res.forEach(function(score){
                    // 		self._session.setItem(score.lesson_id, score.score);
                    // 	})
                    // })
                }
                StudentLesson.prototype.ngOnInit = function () {
                };
                StudentLesson.prototype.getCountLesson = function () {
                    return this.lessonList.length;
                };
                StudentLesson.prototype.getCourseTitle = function () {
                    return this.titleCase(this.course.coursetitle);
                };
                StudentLesson.prototype.getLessonName = function (lesson) {
                    return this.titleCase(lesson.lessonname);
                };
                StudentLesson.prototype.gotoVideoOrQust = function () {
                    this._router.navigate(['StudentLesson']);
                };
                StudentLesson.prototype.getCurrentLessonStatus = function (lesson) {
                    var score = lesson.score;
                    if (Number(score) == -1 && lesson.lock == false) {
                        return "\n\t\t\t\t<div class=\"col-sm-3 text-right\">\n\t                <div> Locked </div>\n\t            </div>\n\t\t\t";
                    }
                    if (lesson.lock == true) {
                        return "<div class=\"col-sm-3 text-right\">\n\t                <div> Ready </div>\n\t            \t</div>\n\t            ";
                    }
                    else if (lesson.score >= 0) {
                        return "\n\t\t\t\t<div class=\"col-sm-3 text-right\">\n\t                <div> <i class=\"ion-checkmark-round m-r-5\"></i> Completed " + lesson.completedAt.toString().slice(0, 10) + " </div>\n\t            </div>\n\t\t\t";
                    }
                };
                StudentLesson.prototype.countVideo = function (lesson) {
                };
                StudentLesson.prototype.gotoLessonVideo = function (lesson, i) {
                    var _this = this;
                    var score = lesson.score;
                    if (Number(score) == -1 && lesson.lock == false) {
                        return false;
                    }
                    this._studentService.getContentsByLessonId(lesson.lesson_id).subscribe(function (res) {
                        _this._session.setItem('SelectedContents', '');
                        _this._session.setItem('SelectedContents', JSON.stringify(res));
                        _this._session.setItem('SelectedLessonById', JSON.stringify(lesson));
                        _this._session.setItem('SelectedLessonId', lesson.lesson_id);
                        _this._session.setItem('SelectedLessonIndex', i);
                        _this._session.setItem('TotalLesson', _this.lessonList.length);
                        _this._router.navigate(['SelectedContent']);
                    });
                };
                StudentLesson.prototype.GotoBackMed = function () {
                    this._router.navigate(['StudentCourse']);
                };
                StudentLesson.prototype.titleCase = function (str) {
                    return str.split(' ').map(function (val) {
                        return val.charAt(0).toUpperCase() + val.substr(1).toLowerCase();
                    }).join(' ');
                };
                StudentLesson = __decorate([
                    core_1.Component({
                        selector: 'student-lesson',
                        templateUrl: '/components/student/lesson/student.html',
                        providers: [session_1.Session, student_1.StudentService],
                        directives: [router_1.ROUTER_DIRECTIVES],
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, student_1.StudentService, router_1.Router])
                ], StudentLesson);
                return StudentLesson;
            }());
            exports_1("StudentLesson", StudentLesson);
        }
    }
});
//# sourceMappingURL=student.js.map