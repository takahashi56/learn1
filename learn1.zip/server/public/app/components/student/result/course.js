System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/student'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, student_1;
    var CourseResult;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (student_1_1) {
                student_1 = student_1_1;
            }],
        execute: function() {
            CourseResult = (function () {
                function CourseResult(_session, _studentService, router) {
                    var _this = this;
                    this._session = _session;
                    this._studentService = _studentService;
                    this.router = router;
                    this.username = "";
                    this.score = 0;
                    this.showResultOrfalse = false;
                    this.showLessonResult = [];
                    this.showOrFalse = false;
                    if (this._session.getCurrentId() == null) {
                        this.router.navigateByUrl('/login');
                    }
                    else {
                        this.showLessonResult = [];
                        this.username = _session.getCurrentUsername();
                        this.coursetitle = this._session.getItem('CourseName');
                        var lessonList = JSON.parse(this._session.getItem('lessonList')), flag = true, count = 0, progress = lessonList.length, total = 0, right = 0;
                        lessonList.forEach(function (lesson) {
                            var status = JSON.parse(_this._session.getItem(lesson.lesson_id)), s = 0;
                            if (Number(status.score) == -1) {
                                flag = false;
                                progress--;
                                s = 0;
                            }
                            else {
                                s = parseInt(status == null ? 0 : status.score);
                            }
                            total += parseInt(status.total);
                            right += Math.floor(status.total * s / 100);
                            s = isNaN(s) ? 0 : s;
                            _this.score += s;
                        });
                        if (!flag)
                            progress = progress / lessonList.length * 100;
                        this.showOrFalse = flag;
                        this.score = isNaN(Math.floor(right / total * 100)) ? 0 : Math.floor(right / total * 100);
                        var student_id = this._session.getCurrentId(), coures_id = this._session.getItem('CourseId'), score = this.score;
                        this._studentService.setCourseScoreWithStudent({ student_id: student_id, course_id: coures_id, score: score, isCompleted: flag, progress: progress }).subscribe(function (res) {
                            if (flag == false) {
                                _this.router.navigate(['StudentCourse']);
                            }
                        });
                        lessonList.forEach(function (lesson) {
                            var status = JSON.parse(_this._session.getItem(lesson.lesson_id)), temp = {
                                lessonname: lesson.lessonname,
                                total: status == null ? 0 : status.total,
                                right: status == null ? 0 : Math.floor(status.total * status.score / 100)
                            };
                            _this.showLessonResult.push(temp);
                        });
                    }
                }
                CourseResult.prototype.showResult = function () {
                    this.showResultOrfalse = true;
                };
                CourseResult.prototype.gotoFinish = function () {
                    this.router.navigate(['StudentCourse']);
                };
                CourseResult.prototype.doLogout = function () {
                    this.router.navigate(['Login']);
                };
                CourseResult = __decorate([
                    core_1.Component({
                        selector: 'student-course-result',
                        templateUrl: '/components/student/result/course.html',
                        providers: [session_1.Session, student_1.StudentService],
                        directives: [router_1.ROUTER_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, student_1.StudentService, router_1.Router])
                ], CourseResult);
                return CourseResult;
            }());
            exports_1("CourseResult", CourseResult);
        }
    }
});
//# sourceMappingURL=course.js.map