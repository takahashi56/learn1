System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/student'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, student_1;
    var LessonResult;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (student_1_1) {
                student_1 = student_1_1;
            }],
        execute: function() {
            LessonResult = (function () {
                function LessonResult(_session, _studentService, router) {
                    this._session = _session;
                    this._studentService = _studentService;
                    this.router = router;
                    this.username = "";
                    if (this._session.getCurrentId() == null) {
                        this.router.navigateByUrl('/login');
                    }
                    else {
                        this.username = _session.getCurrentUsername();
                        this.lessonname = this._session.getItem('LessonName');
                    }
                }
                LessonResult.prototype.gotoNextLesson = function () {
                    var _this = this;
                    var lessonList = JSON.parse(this._session.getItem('lessonList')), self = this, nextlesson = [], count = false, lessonIndex = Number(this._session.getItem('SelectedLessonIndex')) + 1;
                    if (lessonList.length > lessonIndex) {
                        nextlesson = lessonList[lessonIndex];
                        count = true;
                    }
                    if (!count) {
                        this.router.navigate(['CourseResult']);
                    }
                    else {
                        this._studentService.getContentsByLessonId(nextlesson.lesson_id).subscribe(function (res) {
                            _this._session.setItem('SelectedContents', '');
                            _this._session.setItem('SelectedContents', JSON.stringify(res));
                            _this._session.setItem('SelectedLessonById', JSON.stringify(nextlesson));
                            _this._session.setItem('SelectedLessonId', nextlesson.lesson_id);
                            _this._session.setItem('SelectedLessonIndex', lessonIndex);
                            _this._session.setItem('TotalLesson', lessonList.length);
                            _this.router.navigate(['SelectedContent']);
                        });
                    }
                };
                LessonResult.prototype.gotoFinish = function () {
                    this.router.navigate(['CourseResult']);
                };
                LessonResult = __decorate([
                    core_1.Component({
                        selector: 'student-lesson-result',
                        templateUrl: '/components/student/result/student.html',
                        providers: [session_1.Session, student_1.StudentService],
                        directives: [router_1.ROUTER_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, student_1.StudentService, router_1.Router])
                ], LessonResult);
                return LessonResult;
            }());
            exports_1("LessonResult", LessonResult);
        }
    }
});
//# sourceMappingURL=student.js.map