System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/student'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, student_1;
    var StudentVideo;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (student_1_1) {
                student_1 = student_1_1;
            }],
        execute: function() {
            StudentVideo = (function () {
                function StudentVideo(_session, _studentService, _router) {
                    this._session = _session;
                    this._studentService = _studentService;
                    this._router = _router;
                    this.gotoNextContent = new core_1.EventEmitter();
                    this.gotoPreviousContent = new core_1.EventEmitter();
                    this.htmlString = '';
                }
                StudentVideo.prototype.ngOnInit = function () {
                    var _this = this;
                    setInterval(function () {
                        if (_this.htmlString != _this.content.slideContent) {
                            _this.writeContent();
                        }
                    }, 200);
                };
                StudentVideo.prototype.ngAfterViewInit = function () {
                };
                StudentVideo.prototype.writeContent = function () {
                    this.htmlString = this.content.slideContent;
                    document.getElementById('iframe_id')['contentWindow'].document.open();
                    document.getElementById('iframe_id')['contentWindow'].document.write("\n<html><head><style id=\"mceDefaultStyles\" type=\"text/css\">.mce-content-body div.mce-resizehandle {position: absolute;border: 1px solid black;box-sizing: box-sizing;background: #FFF;width: 7px;height: 7px;z-index: 10000}.mce-content-body .mce-resizehandle:hover {background: #000}.mce-content-body img[data-mce-selected],.mce-content-body hr[data-mce-selected] {outline: 1px solid black;resize: none}.mce-content-body .mce-clonedresizable {position: absolute;outline: 1px dashed black;opacity: .5;filter: alpha(opacity=50);z-index: 10000}.mce-content-body .mce-resize-helper {background: #555;background: rgba(0,0,0,0.75);border-radius: 3px;border: 1px;color: white;display: none;font-family: sans-serif;font-size: 12px;white-space: nowrap;line-height: 14px;margin: 5px 10px;padding: 5px;position: absolute;z-index: 10001}\n.mce-visual-caret {position: absolute;background-color: black;background-color: currentcolor;}.mce-visual-caret-hidden {display: none;}*[data-mce-caret] {position: absolute;left: -1000px;right: auto;top: 0;margin: 0;padding: 0;}\n.mce-content-body .mce-offscreen-selection {position: absolute;left: -9999999999px;max-width: 1000000px;}.mce-content-body *[contentEditable=false] {cursor: default;}.mce-content-body *[contentEditable=true] {cursor: text;}\n</style><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><link type=\"text/css\" rel=\"stylesheet\" href=\"https://cdn.tinymce.com/4/skins/lightgray/content.min.css\"><link type=\"text/css\" rel=\"stylesheet\" href=\"//fonts.googleapis.com/css?family=Lato:300,300i,400,400i\"><link type=\"text/css\" rel=\"stylesheet\" href=\"//www.tinymce.com/css/codepen.min.css\"><link rel=\"stylesheet\" data-mce-href=\"https://cdn.tinymce.com/4/plugins/codesample/css/prism.css\" href=\"https://cdn.tinymce.com/4/plugins/codesample/css/prism.css\"></head><body id=\"tinymce\" class=\"mce-content-body \" data-id=\"tinymceN1481899178641\" spellcheck=\"false\">" + this.htmlString + "</body></html>");
                    document.getElementById('iframe_id')['contentWindow'].document.close();
                };
                StudentVideo.prototype.gotoNext = function () {
                    this.gotoNextContent.emit({});
                };
                StudentVideo.prototype.gotoPrevious = function () {
                    this.gotoPreviousContent.emit({});
                };
                StudentVideo.prototype.getEmbedUrl = function () {
                    var videoNumber = this.content.videoEmbedCode.replace(/\D/g, '');
                    if (this.content.videoEmbedCode.includes('youtube')) {
                        return this.content.videoEmbedCode;
                    }
                    else {
                        return 'https://player.vimeo.com/video/' + videoNumber;
                    }
                };
                StudentVideo.prototype.getIndex = function () {
                    return this.index + 1;
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Object)
                ], StudentVideo.prototype, "content", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], StudentVideo.prototype, "lessonname", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Number)
                ], StudentVideo.prototype, "index", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Number)
                ], StudentVideo.prototype, "total", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], StudentVideo.prototype, "gotoNextContent", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], StudentVideo.prototype, "gotoPreviousContent", void 0);
                StudentVideo = __decorate([
                    core_1.Component({
                        selector: 'student-video',
                        templateUrl: '/components/student/video/student.html',
                        providers: [session_1.Session, student_1.StudentService],
                        directives: [router_1.ROUTER_DIRECTIVES],
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, student_1.StudentService, router_1.Router])
                ], StudentVideo);
                return StudentVideo;
            }());
            exports_1("StudentVideo", StudentVideo);
        }
    }
});
//# sourceMappingURL=student.js.map