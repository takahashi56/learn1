System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/student', '../video/student', '../questiontext/student', '../questionchoice/student'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, student_1, student_2, student_3, student_4;
    var SelectedContent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (student_1_1) {
                student_1 = student_1_1;
            },
            function (student_2_1) {
                student_2 = student_2_1;
            },
            function (student_3_1) {
                student_3 = student_3_1;
            },
            function (student_4_1) {
                student_4 = student_4_1;
            }],
        execute: function() {
            SelectedContent = (function () {
                function SelectedContent(_session, _studentService, _router) {
                    this._session = _session;
                    this._studentService = _studentService;
                    this._router = _router;
                    this.currentLesson = [];
                    this.index = 0;
                    if (this._session.getCurrentId() == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        this.contents = JSON.parse(this._session.getItem('SelectedContents'));
                        var count = 0;
                        this.contents.forEach(function (content) {
                            if (content.slideOrQuestion == false) {
                                count++;
                            }
                        });
                        this._session.setItem('questionCount', count);
                        this._session.setItem('rightQuestionCount', 0);
                        this.currentLesson = JSON.parse(this._session.getItem('SelectedLessonById'));
                        this.currentContent = this.contents[0];
                        this.index = 0;
                        this.lessonindex = Number(this._session.getItem('SelectedLessonIndex'));
                        this.lessontotal = Number(this._session.getItem('TotalLesson'));
                        this.lessonname = this.currentLesson.lessonname;
                        this._session.setItem('LessonName', this.lessonname);
                    }
                }
                SelectedContent.prototype.ngOnInit = function () {
                };
                SelectedContent.prototype.gotoNextContent = function (event) {
                    if ((this.index + 1) >= this.contents.length) {
                        return this.gotoResultPage();
                    }
                    else {
                        this.index += 1;
                        this.currentContent = this.contents[this.index];
                    }
                };
                SelectedContent.prototype.gotoPreviousContent = function (event) {
                    if ((this.index - 1) < 0) {
                        this._router.navigate(['StudentLesson']);
                        return false;
                    }
                    this.index -= 1;
                    this.currentContent = this.contents[this.index];
                };
                SelectedContent.prototype.gotoResultPage = function () {
                    var _this = this;
                    var totalCount = Number(this._session.getItem('questionCount')), rightCount = Number(this._session.getItem('rightQuestionCount')), score = Math.floor(rightCount / totalCount * 100), score = isNaN(score) ? 0 : score, lesson_id = this._session.getItem('SelectedLessonId'), student_id = this._session.getCurrentId(), data = {
                        student_id: student_id,
                        lesson_id: lesson_id,
                        score: score,
                    }, status = {
                        total: totalCount,
                        right: rightCount,
                        score: score
                    };
                    this._session.setItem(lesson_id, JSON.stringify(status));
                    this._studentService.setScoreForLesson(data).subscribe(function (res) {
                        _this._router.navigate(['LessonResult']);
                    });
                };
                SelectedContent = __decorate([
                    core_1.Component({
                        selector: 'selected-content',
                        templateUrl: '/components/student/selected/student.html',
                        // template: '<h1>22</h1>',
                        providers: [session_1.Session, student_1.StudentService],
                        directives: [router_1.ROUTER_DIRECTIVES, student_2.StudentVideo, student_3.QuestionText, student_4.QuestionChoice],
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, student_1.StudentService, router_1.Router])
                ], SelectedContent);
                return SelectedContent;
            }());
            exports_1("SelectedContent", SelectedContent);
        }
    }
});
//# sourceMappingURL=student.js.map