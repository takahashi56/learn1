System.register(['angular2/core', 'angular2/router', './main/main', './lesson/student', './questiontext/student', './questionchoice/student', './video/student', './selected/student', './result/student', './result/course'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, main_1, student_1, student_2, student_3, student_4, student_5, student_6, course_1;
    var Student;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (main_1_1) {
                main_1 = main_1_1;
            },
            function (student_1_1) {
                student_1 = student_1_1;
            },
            function (student_2_1) {
                student_2 = student_2_1;
            },
            function (student_3_1) {
                student_3 = student_3_1;
            },
            function (student_4_1) {
                student_4 = student_4_1;
            },
            function (student_5_1) {
                student_5 = student_5_1;
            },
            function (student_6_1) {
                student_6 = student_6_1;
            },
            function (course_1_1) {
                course_1 = course_1_1;
            }],
        execute: function() {
            Student = (function () {
                function Student() {
                }
                Student = __decorate([
                    core_1.Component({
                        selector: 'student',
                        templateUrl: '/components/admin/admin.html',
                        directives: [router_1.ROUTER_DIRECTIVES, router_1.RouterOutlet]
                    }),
                    router_1.RouteConfig([
                        new router_1.Route({ path: '/main', component: main_1.StudentMain, name: 'StudentCourse', useAsDefault: true }),
                        new router_1.Route({ path: '/lesson', component: student_1.StudentLesson, name: 'StudentLesson' }),
                        new router_1.Route({ path: '/selected', component: student_5.SelectedContent, name: 'SelectedContent' }),
                        new router_1.Route({ path: '/text', component: student_2.QuestionText, name: 'QuestionText' }),
                        new router_1.Route({ path: '/choice', component: student_3.QuestionChoice, name: 'QuestionChoice' }),
                        new router_1.Route({ path: '/video', component: student_4.StudentVideo, name: 'StudentVideo' }),
                        new router_1.Route({ path: '/lesson-result', component: student_6.LessonResult, name: 'LessonResult' }),
                        new router_1.Route({ path: '/course-result', component: course_1.CourseResult, name: 'CourseResult' }),
                    ]), 
                    __metadata('design:paramtypes', [])
                ], Student);
                return Student;
            }());
            exports_1("Student", Student);
        }
    }
});
//# sourceMappingURL=student.js.map