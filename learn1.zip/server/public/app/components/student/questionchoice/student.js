System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/student'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, student_1;
    var QuestionChoice;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (student_1_1) {
                student_1 = student_1_1;
            }],
        execute: function() {
            QuestionChoice = (function () {
                function QuestionChoice(_session, _studentService, _router) {
                    this._session = _session;
                    this._studentService = _studentService;
                    this._router = _router;
                    this.courseList = [];
                    this.answerNumber = 0;
                    this.checkedRadio = '0';
                    this.iterator = [1, 2, 3, 4];
                    this.checkedStatus = '';
                    this.gotoNextContent = new core_1.EventEmitter();
                    this.gotoPreviousContent = new core_1.EventEmitter();
                }
                QuestionChoice.prototype.ngOnInit = function () {
                    this.checkedStatus = '<i class="fa"></i>';
                    console.log(this.content);
                };
                QuestionChoice.prototype.chooseAnswer = function (n) {
                    switch (n) {
                        case 1:
                            this.checkedRadio = 'first';
                            break;
                        case 2:
                            this.checkedRadio = 'second';
                            break;
                        case 3:
                            this.checkedRadio = 'third';
                            break;
                        case 4:
                            this.checkedRadio = 'fourth';
                            break;
                        default:
                            this.checkedRadio = '';
                            break;
                    }
                    this.answerNumber = n;
                };
                QuestionChoice.prototype.gotoNext = function () {
                    if (this.checkedRadio == 'fifth')
                        return;
                    if (this.answerNumber == 0)
                        return false;
                    this.checkedRadio = 'fifth';
                    if (this.content.trueNumber == this.answerNumber) {
                        var count = parseInt(this._session.getItem('rightQuestionCount'));
                        count++;
                        this._session.setItem('rightQuestionCount', count);
                    }
                    this.gotoNextContent.emit({});
                };
                QuestionChoice.prototype.gotoPrevious = function () {
                    // this.changeChecked(null);
                    this.checkedRadio = 'fifth';
                    this.gotoPreviousContent.emit({});
                };
                QuestionChoice.prototype.getImagePath = function (image) {
                    return "images/upload/" + image;
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Object)
                ], QuestionChoice.prototype, "content", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], QuestionChoice.prototype, "lessonname", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Number)
                ], QuestionChoice.prototype, "index", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], QuestionChoice.prototype, "gotoNextContent", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], QuestionChoice.prototype, "gotoPreviousContent", void 0);
                QuestionChoice = __decorate([
                    core_1.Component({
                        selector: 'student-choice',
                        templateUrl: '/components/student/questionchoice/student.html',
                        providers: [session_1.Session, student_1.StudentService],
                        directives: [router_1.ROUTER_DIRECTIVES],
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, student_1.StudentService, router_1.Router])
                ], QuestionChoice);
                return QuestionChoice;
            }());
            exports_1("QuestionChoice", QuestionChoice);
        }
    }
});
//# sourceMappingURL=student.js.map