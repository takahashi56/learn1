System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/student'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, student_1;
    var Choice;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (student_1_1) {
                student_1 = student_1_1;
            }],
        execute: function() {
            Choice = (function () {
                function Choice() {
                    this.selectAnswer = new core_1.EventEmitter();
                }
                Choice.prototype.chooseAnswer = function (n) {
                    this.selectAnswer.emit(n);
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], Choice.prototype, "answerA", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], Choice.prototype, "answerB", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], Choice.prototype, "answerC", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], Choice.prototype, "selectAnswer", void 0);
                Choice = __decorate([
                    core_1.Component({
                        selector: 'choice',
                        template: "\n        <div class=\"radio-box m-t-20\">\n            <label class=\"cr-styled\" for=\"answer1\">\n                <input type=\"radio\" name=\"answer\" id=\"answer1\" value=\"1\" (click)=\"chooseAnswer(1)\">\n                <i class=\"fa\"></i>\n                <strong class=\"m-l-10\">{{answerA}}</strong>\n            </label>\n        </div>\n        <div class=\"radio-box m-t-20\">\n            <label class=\"cr-styled\" for=\"answer2\">\n                <input type=\"radio\" name=\"answer\" id=\"answer2\" value=\"2\"  (click)=\"chooseAnswer(2)\">\n                <i class=\"fa\"></i>\n                <strong class=\"m-l-10\">{{answerB}}</strong>\n            </label>\n        </div>\n        <div class=\"radio-box m-t-20\">\n            <label class=\"cr-styled\" for=\"answer3\">\n                <input type=\"radio\" name=\"answer\" id=\"answer3\" value=\"3\" (click)=\"chooseAnswer(3)\">\n                <i class=\"fa\"></i>\n                <strong class=\"m-l-10\">{{answerC}}</strong>\n            </label>\n        </div>\n    ",
                        providers: [session_1.Session, student_1.StudentService],
                        directives: [router_1.ROUTER_DIRECTIVES],
                    }), 
                    __metadata('design:paramtypes', [])
                ], Choice);
                return Choice;
            }());
            exports_1("Choice", Choice);
        }
    }
});
//# sourceMappingURL=choice.js.map