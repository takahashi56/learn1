System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/student'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, student_1;
    var StudentMain;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (student_1_1) {
                student_1 = student_1_1;
            }],
        execute: function() {
            StudentMain = (function () {
                function StudentMain(_session, _studentService, _router) {
                    var _this = this;
                    this._session = _session;
                    this._studentService = _studentService;
                    this._router = _router;
                    this.courseList = [];
                    this.course = {};
                    this.empty = false;
                    this._session.setItem('editORadd', JSON.stringify({ flag: false }));
                    this.studentId = this._session.getItem('MainStudentId');
                    var role = this._session.getCurrentRole(), count = Number(this._session.getItem('CourseCount')), id = this._session.getCurrentId();
                    if (id == null || role == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        if (role == 2) {
                            this._studentService.getCourseListById(this.studentId).subscribe(function (res) {
                                _this.courseList = res;
                            });
                            this._studentService.getStudentInfo(this.studentId).subscribe(function (res) {
                                _this.studentInfo = res;
                            });
                            if (count == 0) {
                                this.empty = true;
                            }
                            else {
                                this.empty = false;
                            }
                        }
                        else {
                            var url = this._session.getItem('homeUrl');
                            this._router.navigateByUrl(url);
                        }
                    }
                }
                StudentMain.prototype.ngOnInit = function () {
                    this._studentService.updateCourse(this.studentId).subscribe(function (res) {
                        console.log('');
                    });
                };
                StudentMain.prototype.gotoLessonList = function (course) {
                    this._session.setItem('selectedCourse', JSON.stringify(course));
                    this._session.setItem('CourseName', this.getCourseName(course));
                    this._session.setItem('CourseId', course.course_id);
                    this._router.navigate(['StudentLesson']);
                };
                StudentMain.prototype.getHeadingClass = function (course) {
                    if (course.isCompleted)
                        return "panel-heading panel-completed";
                    else
                        return "panel-heading";
                };
                StudentMain.prototype.getCourseName = function (course) {
                    return this.titleCase(course.coursetitle);
                };
                StudentMain.prototype.getCurrentStatus = function (course) {
                    if (course.isCompleted == false) {
                        return "In progress " + course.progress + "% Complete";
                    }
                    if (course.isCompleted == true) {
                        return "Completed, " + this.getCompleteDate(course.completedAt) + ", Score " + course.score + "%";
                    }
                };
                StudentMain.prototype.beforeGotoLessonList = function (course) {
                    if (course.isCompleted == false) {
                        this.gotoLessonList(course);
                    }
                    return;
                    // this.course = course;
                };
                StudentMain.prototype.retakeCourse = function () {
                    var _this = this;
                    this._studentService.resetCourse(this.studentId, this.course.course_id).subscribe(function (res) {
                        _this.gotoLessonList(_this.course);
                    });
                };
                StudentMain.prototype.getCompleteDate = function (date) {
                    if (date == null)
                        return '';
                    var d = new Date(date), day = d.getDate().toString().length == 1 ? '0' + d.getDate() : d.getDate(), month = (d.getMonth() + 1).toString().length == 1 ? '0' + (d.getMonth() + 1) : (d.getMonth() + 1), datestring = day + "/" + month + "/" + d.getFullYear();
                    return datestring;
                };
                StudentMain.prototype.titleCase = function (str) {
                    return str.split(' ').map(function (val) {
                        return val.charAt(0).toUpperCase() + val.substr(1).toLowerCase();
                    }).join(' ');
                };
                StudentMain = __decorate([
                    core_1.Component({
                        selector: 'student-main',
                        templateUrl: '/components/student/main/main.html',
                        providers: [session_1.Session, student_1.StudentService],
                        directives: [router_1.ROUTER_DIRECTIVES],
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, student_1.StudentService, router_1.Router])
                ], StudentMain);
                return StudentMain;
            }());
            exports_1("StudentMain", StudentMain);
        }
    }
});
//# sourceMappingURL=main.js.map