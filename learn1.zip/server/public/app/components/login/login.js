System.register(['angular2/core', '../../services/session', 'angular2/router', '../../services/authentication', 'angular2/common', '../home/home'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, authentication_1, common_1, home_1;
    var Login;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (authentication_1_1) {
                authentication_1 = authentication_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (home_1_1) {
                home_1 = home_1_1;
            }],
        execute: function() {
            Login = (function () {
                function Login(_session, _authService, _router, builder) {
                    this._session = _session;
                    this._authService = _authService;
                    this._router = _router;
                    this.builder = builder;
                    this.actionPath = "";
                    this.text = "";
                    this.submitAttempt = false;
                    this.authFailure = false;
                    this.remember_me = false;
                    this.actionPath = "";
                    this.text = "";
                    var username = _session.getCurrentUsername(), role = _session.getCurrentRole(), id = _session.getCurrentId();
                    if (username != null && role != null && id != null) {
                        var url = _session.getItem('homeUrl');
                        this._router.navigateByUrl('/home');
                    }
                    else {
                        this.username = new common_1.Control('', common_1.Validators.required);
                        this.password = new common_1.Control('', common_1.Validators.compose([common_1.Validators.required, common_1.Validators.minLength(6)]));
                        this.LoginForm = builder.group({
                            username: this.username,
                            password: this.password
                        });
                        this.remember_me = JSON.parse(this._session.getItem('remember_me'));
                        if (this.remember_me == true) {
                            this.LoginForm.controls['username'].updateValue(this._session.getItem('usrname'));
                            this.LoginForm.controls['password'].updateValue(this._session.getItem('pass'));
                        }
                    }
                }
                Login.prototype.doLogin = function (form) {
                    var _this = this;
                    this.authFailure = false;
                    this.submitAttempt = true;
                    if (this.LoginForm.valid) {
                        var data = {
                            username: form.username,
                            password: form.password
                        };
                        this._authService.Login(data)
                            .subscribe(function (res) {
                            if (res.success) {
                                _this._session.setUser(res.name, res.role, res._id);
                                _this._session.setItem('homeUrl', res.action);
                                if (res.role == 2) {
                                    _this._session.setItem('MainStudentId', res.id);
                                    _this._session.setItem('CourseCount', res.count);
                                }
                                if (res.role == 1) {
                                    _this._session.setItem("organization", res.organization);
                                    _this._session.setItem("creditcount", res.creditcount);
                                    _this._session.setItem("employeecount", res.employeecount);
                                    _this._session.setItem("subscribing", res.subscribing);
                                    _this._session.setItem("stripe_publish_key", res.stripe_publish_key);
                                }
                                _this._router.navigateByUrl('/home');
                            }
                            else {
                                _this.authFailure = true;
                            }
                        });
                    }
                };
                Login.prototype.onClickRemember = function (remember_me) {
                    if (this.remember_me == false) {
                        this._session.setItem('usrname', $('#username').val());
                        this._session.setItem('pass', $('#pass').val());
                        this._session.setItem('remember_me', !this.remember_me);
                    }
                    else {
                        this._session.setItem('usrname', '');
                        this._session.setItem('pass', '');
                        this._session.setItem('remember_me', false);
                    }
                };
                Login = __decorate([
                    core_1.Component({
                        selector: 'login',
                        templateUrl: '/components/login/login.html',
                        providers: [session_1.Session, authentication_1.AuthService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES, home_1.Home]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, authentication_1.AuthService, router_1.Router, common_1.FormBuilder])
                ], Login);
                return Login;
            }());
            exports_1("Login", Login);
        }
    }
});
//# sourceMappingURL=login.js.map