System.register(['angular2/core', '../../services/session', 'angular2/router', '../../services/admin', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, admin_1, common_1;
    var SignUp;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (admin_1_1) {
                admin_1 = admin_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            SignUp = (function () {
                function SignUp(_session, _adminService, builder, _router) {
                    this._session = _session;
                    this._adminService = _adminService;
                    this.builder = builder;
                    this._router = _router;
                    this.submitAttempt = false;
                    this.registerFailure = false;
                    this.check_accept = false;
                    this.firstName = new common_1.Control('', common_1.Validators.required);
                    this.lastName = new common_1.Control('', common_1.Validators.required);
                    this.organization = new common_1.Control('', common_1.Validators.required);
                    this.email = new common_1.Control('', common_1.Validators.required);
                    this.phone = new common_1.Control('', common_1.Validators.required);
                    this.password = new common_1.Control('', common_1.Validators.compose([common_1.Validators.required, common_1.Validators.minLength(6)]));
                    this.OrganizeForm = builder.group({
                        firstName: this.firstName,
                        lastName: this.lastName,
                        organization: this.organization,
                        email: this.email,
                        phone: this.phone,
                        password: this.password
                    });
                }
                SignUp.prototype.isNumberKey = function (evt) {
                    evt = (evt) ? evt : window.event;
                    var charCode = (evt.which) ? evt.which : evt.keyCode;
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    return true;
                };
                SignUp.prototype.checkAccept = function (event) {
                    if (event.currentTarget.checked) {
                        this.check_accept = true;
                    }
                    else {
                        this.check_accept = false;
                    }
                };
                SignUp.prototype.AddOrgs = function (form) {
                    var _this = this;
                    this.registerFailure = false;
                    this.submitAttempt = true;
                    if (this.OrganizeForm.valid && this.check_accept) {
                        var data = {
                            firstName: form.firstName,
                            lastName: form.lastName,
                            organization: form.organization,
                            email: form.email,
                            password: form.password,
                            phone: form.phone,
                            employeecount: 0,
                            creditcount: 0,
                            subscribing: false,
                        };
                        this._adminService.addTutor(data)
                            .subscribe(function (res) {
                            if (res.success) {
                                _this._session.setUser(data.email, res.role, res._id);
                                _this._session.setItem('homeUrl', res.action);
                                _this._router.navigateByUrl('/home/tutor/main');
                            }
                            if (res.errmsg || res.success == false) {
                                _this.registerFailure = true;
                            }
                        });
                    }
                };
                SignUp = __decorate([
                    core_1.Component({
                        selector: 'signup',
                        templateUrl: '/components/signup/signup.html',
                        providers: [session_1.Session, admin_1.AdminService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES],
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, admin_1.AdminService, common_1.FormBuilder, router_1.Router])
                ], SignUp);
                return SignUp;
            }());
            exports_1("SignUp", SignUp);
        }
    }
});
//# sourceMappingURL=signup.js.map