System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/tutor', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, tutor_1, common_1;
    var GoCardlessPayment;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (tutor_1_1) {
                tutor_1 = tutor_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            GoCardlessPayment = (function () {
                function GoCardlessPayment(_session, _tutorService, builder, _router) {
                    this._session = _session;
                    this._tutorService = _tutorService;
                    this.builder = builder;
                    this._router = _router;
                    this.tutor_id = "";
                    this.employeecount = 0;
                    this.redirect_url = [
                        'https://pay-sandbox.gocardless.com/AL00002P3VZFPJ',
                        'https://pay-sandbox.gocardless.com/AL00002P3W7CSR',
                        'https://pay-sandbox.gocardless.com/AL00002P3XTTRW',
                        'https://pay-sandbox.gocardless.com/AL00002P3ZJ64C',
                        'https://pay-sandbox.gocardless.com/AL00002P405VDM'
                    ];
                    if (this._session.getCurrentId() == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        this.tutor_id = this._session.getCurrentId();
                        this.employeecount = Number(this._session.getItem('employeecount'));
                        if (Number(this._session.getItem('subscribing')) == 0) {
                            var students = JSON.parse(this._session.getItem('TutorAllStudent')) || [];
                            this.employeecount = students.length;
                        }
                    }
                }
                GoCardlessPayment.prototype.gotoGoCardlessPage = function (num, count, amount) {
                    var _this = this;
                    this._tutorService.getRedirectUrl({ tutor_id: this.tutor_id, count: count, amount: amount }).subscribe(function (res) {
                        window.open(_this.redirect_url[num], '_self');
                    });
                };
                GoCardlessPayment.prototype.cancel = function () {
                    this._router.navigate(['TutorMain']);
                };
                GoCardlessPayment.prototype.getStatus = function (num) {
                    if (num > this.employeecount) {
                        return false;
                    }
                    else {
                        return true;
                    }
                };
                GoCardlessPayment = __decorate([
                    core_1.Component({
                        selector: 'tutor-gocardless-tutor',
                        templateUrl: '/components/tutor/gocardless/tutor.html',
                        providers: [session_1.Session, tutor_1.TutorService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, tutor_1.TutorService, common_1.FormBuilder, router_1.Router])
                ], GoCardlessPayment);
                return GoCardlessPayment;
            }());
            exports_1("GoCardlessPayment", GoCardlessPayment);
        }
    }
});
//# sourceMappingURL=tutor.js.map