System.register(['angular2/core', 'angular2/router', '../../../services/session', '../../../services/tutor'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, session_1, tutor_1;
    var PastTutorStudent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (tutor_1_1) {
                tutor_1 = tutor_1_1;
            }],
        execute: function() {
            PastTutorStudent = (function () {
                function PastTutorStudent(_session, _tutorService, _router) {
                    var _this = this;
                    this._session = _session;
                    this._tutorService = _tutorService;
                    this._router = _router;
                    this.pastStudents = [];
                    this.tutor_id = '';
                    this.selectStudents = [];
                    this.showRemoveStudent = false;
                    this.selectedStudentsName = '';
                    if (this._session.getCurrentId() == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        this.tutor_id = this._session.getCurrentId();
                        this._tutorService.getArchivedStudents({ tutor_id: this.tutor_id }).subscribe(function (res) {
                            _this.pastStudents = res;
                        });
                    }
                }
                PastTutorStudent.prototype.ngAfterViewInit = function () {
                };
                PastTutorStudent.prototype.beforeRemoveStudent = function () {
                    var _this = this;
                    if (this.selectStudents.length == 0) {
                        this.showRemoveStudent = false;
                        return false;
                    }
                    this.showRemoveStudent = true;
                    var instance = this;
                    var data = [];
                    this.selectStudents.map(function (id) {
                        var element = _this.pastStudents.filter(function (student) { return student._id == id; });
                        data.push(element[0].firstName + " " + element[0].lastName);
                    });
                    this.selectedStudentsName = data.join(',');
                };
                PastTutorStudent.prototype.checkStudent = function (event, object) {
                    if (event.currentTarget.checked) {
                        this.selectStudents.push(object._id);
                    }
                    else {
                        this.selectStudents = this.selectStudents.filter(function (o) {
                            return o != object._id;
                        });
                    }
                };
                PastTutorStudent.prototype.cancel = function () {
                    this._router.navigate(['TutorMain']);
                };
                PastTutorStudent.prototype.restoreEmployee = function () {
                    var _this = this;
                    if (this.selectStudents.length == 0)
                        return false;
                    this._tutorService.restoreStudentById({ list: this.selectStudents }).subscribe(function (res) {
                        _this.selectStudents.map(function (id) {
                            _this.pastStudents = _this.pastStudents.filter(function (student) {
                                return student._id != id;
                            });
                        });
                    });
                };
                PastTutorStudent.prototype.fullyRemove = function () {
                    var _this = this;
                    if (this.selectStudents.length == 0)
                        return false;
                    this._tutorService.removeStudentById(this.selectStudents).subscribe(function (res) {
                        _this.selectStudents.map(function (id) {
                            _this.pastStudents = _this.pastStudents.filter(function (student) {
                                return student._id != id;
                            });
                        });
                    });
                };
                PastTutorStudent.prototype.gotoStudentDetail = function (student) {
                    student["student_id"] = student._id;
                    this._session.setItem('editORadd', JSON.stringify({ flag: true }));
                    this._session.setItem('TutorStudent', JSON.stringify(student));
                    this._session.setItem('pastRoute', true);
                    this._router.navigate(['DetailTutorStudent']);
                };
                PastTutorStudent.prototype.getCompleteDate = function (student) {
                    var date = student.archivedDate;
                    var d = new Date(date), day = d.getDate().toString().length == 1 ? '0' + d.getDate() : d.getDate(), month = (d.getMonth() + 1).toString().length == 1 ? '0' + (d.getMonth() + 1) : (d.getMonth() + 1), datestring = day + "/" + month + "/" + d.getFullYear();
                    return datestring;
                };
                PastTutorStudent = __decorate([
                    core_1.Component({
                        selector: 'tutor-past',
                        templateUrl: '/components/tutor/past/tutor.html',
                        providers: [session_1.Session, tutor_1.TutorService],
                        directives: [router_1.ROUTER_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, tutor_1.TutorService, router_1.Router])
                ], PastTutorStudent);
                return PastTutorStudent;
            }());
            exports_1("PastTutorStudent", PastTutorStudent);
        }
    }
});
//# sourceMappingURL=tutor.js.map