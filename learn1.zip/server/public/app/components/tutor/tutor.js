System.register(['angular2/core', 'angular2/router', './main/main', './add/student', './detail/student', './detail/course', './stripe/tutor', './gocardless/tutor', './gocardless/success', './gocardless/failure', './past/tutor'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, main_1, student_1, student_2, course_1, tutor_1, tutor_2, success_1, failure_1, tutor_3;
    var Tutor;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (main_1_1) {
                main_1 = main_1_1;
            },
            function (student_1_1) {
                student_1 = student_1_1;
            },
            function (student_2_1) {
                student_2 = student_2_1;
            },
            function (course_1_1) {
                course_1 = course_1_1;
            },
            function (tutor_1_1) {
                tutor_1 = tutor_1_1;
            },
            function (tutor_2_1) {
                tutor_2 = tutor_2_1;
            },
            function (success_1_1) {
                success_1 = success_1_1;
            },
            function (failure_1_1) {
                failure_1 = failure_1_1;
            },
            function (tutor_3_1) {
                tutor_3 = tutor_3_1;
            }],
        execute: function() {
            Tutor = (function () {
                function Tutor() {
                }
                Tutor = __decorate([
                    core_1.Component({
                        selector: 'tutor',
                        templateUrl: '/components/admin/admin.html',
                        directives: [router_1.ROUTER_DIRECTIVES, router_1.RouterOutlet]
                    }),
                    router_1.RouteConfig([
                        new router_1.Route({ path: '/main', component: main_1.TutorMain, name: 'TutorMain', useAsDefault: true }),
                        new router_1.Route({ path: '/main/stripe', component: tutor_1.StripePayment, name: 'StripePayment' }),
                        new router_1.Route({ path: '/main/gocardless', component: tutor_2.GoCardlessPayment, name: 'GoCardlessPayment' }),
                        new router_1.Route({ path: '/main/gocardless/success', component: success_1.GoCardlessPaymentSuccess, name: 'GoCardlessPaymentSuccess' }),
                        new router_1.Route({ path: '/main/gocardless/failure', component: failure_1.GoCardlessPaymentFailure, name: 'GoCardlessPaymentFailure' }),
                        new router_1.Route({ path: '/add/student', component: student_1.AddTutorStudent, name: 'AddTutorStudent' }),
                        new router_1.Route({ path: '/detail/student', component: student_2.DetailTutorStudent, name: 'DetailTutorStudent' }),
                        new router_1.Route({ path: '/detail/course', component: course_1.DetailTutorCourse, name: 'DetailTutorCourse' }),
                        new router_1.Route({ path: '/main/past', component: tutor_3.PastTutorStudent, name: 'PastTutorStudent' })
                    ]), 
                    __metadata('design:paramtypes', [])
                ], Tutor);
                return Tutor;
            }());
            exports_1("Tutor", Tutor);
        }
    }
});
//# sourceMappingURL=tutor.js.map