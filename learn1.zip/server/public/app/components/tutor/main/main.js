System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/tutor', 'angular2/platform/common', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, tutor_1, common_1, common_2;
    var TutorMain;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (tutor_1_1) {
                tutor_1 = tutor_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (common_2_1) {
                common_2 = common_2_1;
            }],
        execute: function() {
            TutorMain = (function () {
                function TutorMain(_location, _session, _tutorService, _router, builder) {
                    var _this = this;
                    this._location = _location;
                    this._session = _session;
                    this._tutorService = _tutorService;
                    this._router = _router;
                    this.builder = builder;
                    this.studentList = [];
                    this.courseList = [];
                    this.selectStudents = [];
                    this.showArchiveStudent = false;
                    this.selectedStudentsName = '';
                    this.creditcount = 0;
                    this.employeecount = 0;
                    this.validateoldconfirm = false;
                    this.validatenewconfirm = false;
                    this.changeSuccess = false;
                    this.showAlert = false;
                    this.validOldPassword = true;
                    this.failure = '';
                    this.matchedTrue = false;
                    this.select_tab_item = 1;
                    this.employee_tab = '';
                    this.course_tab = '';
                    this.setting_tab = '';
                    this.credits_tab = '';
                    this.showAssignCourse = false;
                    this.displayCanAssign = false;
                    this.showAssignStudent = false;
                    this.show_not_assign = false;
                    this.changePasswordSuccess = false;
                    this.show_password = false;
                    this.showNotAssign = false;
                    this.success_subscription = false;
                    this.tutor_id = this._session.getCurrentId();
                    if (this.tutor_id == "" || this.tutor_id == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        var role = this._session.getCurrentRole();
                        this._session.setItem('editORadd', JSON.stringify({ flag: false }));
                        this.creditcount = Number(this._session.getItem('creditcount'));
                        this.employeecount = Number(this._session.getItem('employeecount'));
                        this.loadData();
                        this._tutorService.updateTutorInfo({ tutor_id: this.tutor_id }).subscribe(function (res) {
                            _this._session.setItem('employeecount', res.employeecount);
                            _this._session.setItem('subscribing', res.subscribing == true ? 1 : 0);
                            _this._session.setItem('creditcount', res.creditcount);
                            _this.creditcount = Number(_this._session.getItem('creditcount'));
                            _this.employeecount = Number(_this._session.getItem('employeecount'));
                        });
                        this.oldpwd = new common_2.Control('', common_2.Validators.compose([common_2.Validators.required, common_2.Validators.minLength(6)]));
                        this.newpwd = new common_2.Control('', common_2.Validators.compose([common_2.Validators.required, common_2.Validators.minLength(6)]));
                        this.newpwdconfirm = new common_2.Control('', common_2.Validators.compose([common_2.Validators.required, common_2.Validators.minLength(6)]));
                        this.SettingForm = builder.group({
                            newpwd: this.newpwd,
                            newpwdconfirm: this.newpwdconfirm,
                            oldpwd: this.oldpwd
                        });
                        if (JSON.parse(this._session.getItem('success_subscription')) == true) {
                            this.success_subscription = true;
                            setTimeout(function () {
                                _this._session.setItem('success_subscription', false);
                                _this.success_subscription = false;
                            }, 4000);
                        }
                        else {
                            this.success_subscription = false;
                        }
                        setInterval(function () {
                            if (_this._session.getItem('select_tutor_tab') == null) {
                                _this.onTabClick(1);
                            }
                            else {
                                _this.onTabClick(Number(_this._session.getItem('select_tutor_tab')));
                            }
                        }, 100);
                    }
                }
                TutorMain.prototype.loadData = function () {
                    var _this = this;
                    this.showAssignCourse = false;
                    this.selectStudents = [];
                    this._tutorService.getAllCourses({ tutor_id: this.tutor_id }).subscribe(function (res) {
                        _this.courseList = res;
                    });
                    this._tutorService.getAllStudents({ tutor_id: this.tutor_id }).subscribe(function (res) {
                        _this.studentList = res;
                        _this._session.setItem('TutorAllStudent', JSON.stringify(res));
                    });
                    this._tutorService.getAllMatrix({ tutor_id: this.tutor_id }).subscribe(function (res) {
                        _this._session.setItem('studentList', JSON.stringify(res));
                    });
                };
                TutorMain.prototype.editStudent = function (student) {
                    this._session.setItem('editORadd', JSON.stringify({ flag: true }));
                    this._session.setItem('TutorStudent', JSON.stringify(student));
                    this._router.navigate(['AddTutorStudent']);
                };
                TutorMain.prototype.ngOnInit = function () {
                    if (this.tutor_id == "" || this.tutor_id == null) {
                        this._router.navigateByUrl('/login');
                    }
                };
                TutorMain.prototype.gotoStudentDetail = function (student) {
                    this._session.setItem('editORadd', JSON.stringify({ flag: true }));
                    this._session.setItem('TutorStudent', JSON.stringify(student));
                    this._session.setItem('pastRoute', false);
                    this._router.navigate(['DetailTutorStudent']);
                };
                TutorMain.prototype.gotoDetail = function (course) {
                    this._session.setItem('TutorCourse', JSON.stringify(course));
                    this._router.navigate(['DetailTutorCourse']);
                };
                TutorMain.prototype.gotoAddStudent = function () {
                    var data = {
                        student_id: Date.now(),
                        firstName: '',
                        lastName: '',
                        DOB: ' /00/ ',
                        username: '',
                        hashed_pwd: '',
                        other: '',
                        phone: '',
                    };
                    var studentLength = this.studentList.length;
                    if ((studentLength + 1) > Number(this._session.getItem('employeecount')) && Number(this._session.getItem('subscribing')) == 1) {
                        this.show_not_assign = true;
                        return;
                    }
                    else {
                        this.show_not_assign = false;
                        this._session.setItem('editORadd', JSON.stringify({ flag: false }));
                        this._session.setItem('TutorStudent', JSON.stringify(data));
                        this._router.navigate(['AddTutorStudent']);
                    }
                };
                TutorMain.prototype.beforeAssign = function () {
                    if (this.selectStudents.length == 0)
                        return false;
                    if (this.selectStudents.length != 0 && (Number(this._session.getItem('creditcount')) != 0 || Number(this._session.getItem('subscribing')) == 1)) {
                        this.showAssignCourse = true;
                        this.displayCanAssign = false;
                    }
                    else {
                        this.showAssignCourse = true;
                        this.displayCanAssign = true;
                    }
                };
                TutorMain.prototype.isAssign = function () {
                    if (Number(this._session.getItem('subscribing')) == 1 && Number(this._session.getItem('employeecount')) <= this.studentList.length) {
                        return true;
                    }
                    else {
                        return false;
                    }
                };
                TutorMain.prototype.beforeAssignStudent = function (course) {
                    if (Number(this._session.getItem('creditcount')) != 0 || Number(this._session.getItem('subscribing')) == 1) {
                        this.showAssignStudent = true;
                        this._session.setItem('AssignCourse', course.course_id);
                        this.displayCanAssign = false;
                    }
                    else {
                        this.showAssignStudent = true;
                        this.displayCanAssign = true;
                    }
                };
                TutorMain.prototype.onSelectCourse = function (value) {
                    this._session.setItem('SelectCourseWithId', value);
                };
                TutorMain.prototype.onSelectStudent = function (value) {
                    this._session.setItem('SelectStudentWithId', value);
                };
                TutorMain.prototype.studentAssign = function () {
                    var _this = this;
                    var id = this._session.getItem('SelectStudentWithId');
                    if (!id)
                        return false;
                    if (Number(this._session.getItem('creditcount')) == 0 && Number(this._session.getItem('subscribing')) == 0)
                        return false;
                    var selectedId = this._session.getItem('AssignCourse');
                    if (!selectedId)
                        return false;
                    var ids = [];
                    ids.push(id);
                    this._tutorService.setAssignStudentsWithCourse(this.tutor_id, selectedId, ids).subscribe(function (res) {
                        _this._session.setItem('creditcount', res.creditcount);
                        if (res.notAssign == 0)
                            alert("This employee is already assigned to this course.");
                        _this._router.navigateByUrl('/home/tutor/main');
                        _this.loadData();
                    });
                    ;
                };
                TutorMain.prototype.courseAssign = function () {
                    var _this = this;
                    var id = this._session.getItem('SelectCourseWithId');
                    if (!id)
                        return false;
                    if (Number(this._session.getItem('creditcount')) == 0 && Number(this._session.getItem('subscribing')) == 0)
                        return false;
                    if (this.selectStudents.length == 0)
                        return false;
                    var ids = this.selectStudents;
                    this._tutorService.setAssignStudentsWithCourse(this.tutor_id, id, ids).subscribe(function (res) {
                        _this._session.setItem('creditcount', res.creditcount);
                        // if(res.notAssign > 0 ) alert(`${res.notAssign} employees cannot be assigned to this course.`)
                        if (res.notAssign == 1)
                            alert("This employee is already assigned to this course.");
                        _this._router.navigateByUrl('/home/tutor/main');
                        _this.loadData();
                    });
                };
                TutorMain.prototype.importAddStudent = function ($event) {
                    var _this = this;
                    var self = this;
                    var file = $event.target.files[0];
                    var myReader = new FileReader();
                    myReader.readAsText(file);
                    var resultSet = [];
                    myReader.onloadend = function (e) {
                        // you can perform an action with data read here
                        // as an example i am just splitting strings by spaces
                        var columns = myReader.result.split(/\r\n|\r|\n/g);
                        for (var i = 0; i < columns.length; i++) {
                            if (columns[i].split(',').length < 3)
                                continue;
                            resultSet.push(columns[i].split(']'));
                        }
                        var studentLength = _this.studentList.length, remainderLength = 0;
                        if ((studentLength + resultSet.length) > _this.employeecount) {
                            remainderLength = (studentLength + resultSet.length) - _this.employeecount;
                        }
                        if (remainderLength <= 0) {
                            return false;
                        }
                        else {
                            resultSet = resultSet.slice(0, remainderLength);
                        }
                        self._tutorService.addStudentCSV({ result: resultSet, tutor_id: self._session.getCurrentId() }).subscribe(function (res) {
                            // self._router.navigateByUrl('/home/tutor/main');
                            self._tutorService.getAllStudents({ tutor_id: self.tutor_id }).subscribe(function (res) {
                                self.studentList = res;
                                self._session.setItem('TutorAllStudent', JSON.stringify(res));
                            });
                            _this._tutorService.getAllMatrix({ tutor_id: _this.tutor_id }).subscribe(function (res) {
                                _this._session.setItem('studentList', JSON.stringify(res));
                            });
                        });
                    };
                };
                TutorMain.prototype.assignCourseToStudent = function () {
                };
                TutorMain.prototype.assignStudentToCourse = function () {
                };
                TutorMain.prototype.gotoCourseByClick = function () {
                };
                TutorMain.prototype.doLogin = function (form) {
                };
                TutorMain.prototype.checkStudent = function (event, object) {
                    if (event.currentTarget.checked) {
                        this.selectStudents.push(object.student_id);
                    }
                    else {
                        this.selectStudents = this.selectStudents.filter(function (o) {
                            return o != object.student_id;
                        });
                    }
                };
                TutorMain.prototype.archiveStudent = function () {
                    var _this = this;
                    if (this.selectStudents.length == 0)
                        return false;
                    var instance = this;
                    this._tutorService.archiveStudentById({ list: this.selectStudents }).subscribe(function (res) {
                        _this.selectStudents.map(function (id) {
                            _this.studentList = _this.studentList.filter(function (student) {
                                return student.student_id != id;
                            });
                            _this._session.setItem('TutorAllStudent', JSON.stringify(_this.studentList));
                            _this._tutorService.getAllMatrix({ tutor_id: _this.tutor_id }).subscribe(function (res) {
                                _this._session.setItem('studentList', JSON.stringify(res));
                            });
                        });
                    });
                };
                TutorMain.prototype.beforeArchiveStudent = function () {
                    var _this = this;
                    if (this.selectStudents.length == 0) {
                        this.showArchiveStudent = false;
                        return false;
                    }
                    this.showArchiveStudent = true;
                    var instance = this;
                    var data = [];
                    this.selectStudents.map(function (id) {
                        var element = _this.studentList.filter(function (student) { return student.student_id == id; });
                        data.push(element[0].firstName + " " + element[0].lastName);
                    });
                    this.selectedStudentsName = data.join(',');
                };
                TutorMain.prototype.gotoMatrix = function () {
                    if (this.courseList == [] || this.courseList == null || this.courseList.length == 0)
                        return false;
                    this._session.setItem('courseList', JSON.stringify(this.courseList));
                    var baseurl = window.location.origin + window.location.pathname + '#/home/tutor/matrix';
                    window.open(baseurl, '_blank');
                    // this._router.navigateByUrl('/home/tutor/matrix');
                };
                TutorMain.prototype.gotoUncompleted = function () {
                    if (this.courseList == [] || this.courseList == null || this.courseList.length == 0)
                        return false;
                    this._session.setItem('courseList', JSON.stringify(this.courseList));
                    var baseurl = window.location.origin + window.location.pathname + '#/home/tutor/uncompleted';
                    window.open(baseurl, '_blank');
                    // this._router.navigateByUrl('/home/tutor/matrix');
                };
                TutorMain.prototype.matchedPassword = function (form) {
                    var password = form.newpwd, verifiedpassword = form.newpwdconfirm;
                    if (this.validatenewconfirm == true && password == verifiedpassword) {
                        this.matchedTrue = true;
                        return true;
                    }
                    else if (verifiedpassword != '' && password != verifiedpassword && this.validatenewconfirm == true) {
                        this.showAlert = true;
                        this.changeSuccess = false;
                        this.failure = 'The Password must be matched';
                        this.matchedTrue = false;
                        return false;
                    }
                    else if (password != '' && password.length > 5 && verifiedpassword == '' && this.validatenewconfirm == true) {
                        this.showAlert = true;
                        this.changeSuccess = false;
                        this.failure = 'The Confirm Password is Required';
                        this.matchedTrue = false;
                        return false;
                    }
                };
                TutorMain.prototype.ChangePassowrd = function (form) {
                    var _this = this;
                    if (form.oldpwd == "" || form.oldpwd == null || this.validOldPassword == true) {
                        this.validateoldconfirm = true;
                        return;
                    }
                    this.validatenewconfirm = true;
                    if (this.validateNewPwd(form.newpwd))
                        return;
                    if (!this.matchedTrue) {
                    }
                    if (this.SettingForm.valid && this.matchedTrue) {
                        var newPwd = form.newpwd;
                        this._tutorService.changePassword({ tutor_id: this.tutor_id, pwd: newPwd }).subscribe(function (res) {
                            _this.changePasswordSuccess = false;
                            if (res.success) {
                                _this.changePasswordSuccess = true;
                            }
                            else {
                                _this.showAlert = true;
                                _this.changeSuccess = false;
                                _this.failure = 'Your update have been failed.';
                            }
                        });
                    }
                };
                TutorMain.prototype.blurChange = function (form) {
                    this.changePasswordSuccess = false;
                    var oldPwd = form.oldpwd;
                    this.isValidOldPassword(oldPwd);
                };
                TutorMain.prototype.focusEvent = function () {
                    this.changePasswordSuccess = false;
                };
                TutorMain.prototype.validateNewPwd = function (newpassword) {
                    if (this.validatenewconfirm == true && newpassword == "") {
                        this.showAlert = true;
                        this.changeSuccess = false;
                        this.failure = 'New Password is Required!';
                        return true;
                    }
                    else if (this.validatenewconfirm == true && newpassword.length < 6) {
                        this.showAlert = true;
                        this.changeSuccess = false;
                        this.failure = 'Password must be at least 6 characters!';
                        return true;
                    }
                    this.showAlert = false;
                    return false;
                };
                TutorMain.prototype.onKey = function (event) {
                    if (event.keyCode !== 13)
                        return;
                    var value = event.target.value;
                    this.isValidOldPassword(value);
                };
                TutorMain.prototype.isValidOldPassword = function (pwd) {
                    var _this = this;
                    this.validateoldconfirm = true;
                    this._tutorService.isValidOldPassword({ tutor_id: this.tutor_id, pwd: pwd }).subscribe(function (res) {
                        if (res.success) {
                            _this.validOldPassword = false;
                        }
                        else {
                            _this.validOldPassword = true;
                            _this.validateoldconfirm = false;
                        }
                    });
                };
                TutorMain.prototype.cancel = function (form) {
                    this.SettingForm.controls['oldpwd'].updateValue('');
                    this.SettingForm.controls['newpwd'].updateValue('');
                    this.SettingForm.controls['newpwdconfirm'].updateValue('');
                };
                /*Stripe Payment*/
                TutorMain.prototype.gotoStripePayment = function () {
                    this._router.navigate(['StripePayment']);
                };
                /*GoCardless Payment*/
                TutorMain.prototype.gotoGoCardlessPayment = function () {
                    this._router.navigate(['GoCardlessPayment']);
                };
                TutorMain.prototype.onTabClick = function (num) {
                    this.course_tab = "tab-pane";
                    this.employee_tab = "tab-pane";
                    this.setting_tab = "tab-pane";
                    this.credits_tab = "tab-pane";
                    this._session.setItem('select_tutor_tab', num);
                    this.select_tab_item = num;
                    switch (num) {
                        case 1:
                            this.employee_tab = "tab-pane active";
                            break;
                        case 2:
                            this.course_tab = "tab-pane active";
                            break;
                        case 3:
                            this.setting_tab = "tab-pane active";
                            break;
                        case 4:
                            this.credits_tab = "tab-pane active";
                            break;
                        default:
                            break;
                    }
                };
                TutorMain.prototype.showPassword = function () {
                    this.show_password = !this.show_password;
                };
                TutorMain.prototype.downloadSampleFile = function () {
                    window.location.href = '/csv/SampleEmployeeImport.csv';
                };
                TutorMain.prototype.downloadFile = function (data) {
                    var blob = new Blob([data], { type: 'text/csv' });
                    var url = window.URL.createObjectURL(blob);
                    window.open(url);
                };
                TutorMain.prototype.pastEmployees = function () {
                    this._router.navigate(['PastTutorStudent']);
                };
                TutorMain = __decorate([
                    core_1.Component({
                        selector: 'tutor-main',
                        templateUrl: '/components/tutor/main/main.html',
                        providers: [session_1.Session, tutor_1.TutorService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_2.FORM_DIRECTIVES],
                    }), 
                    __metadata('design:paramtypes', [common_1.Location, session_1.Session, tutor_1.TutorService, router_1.Router, common_2.FormBuilder])
                ], TutorMain);
                return TutorMain;
            }());
            exports_1("TutorMain", TutorMain);
        }
    }
});
//# sourceMappingURL=main.js.map