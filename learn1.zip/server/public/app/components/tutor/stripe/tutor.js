System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/tutor', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, tutor_1, common_1;
    var StripePayment;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (tutor_1_1) {
                tutor_1 = tutor_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            StripePayment = (function () {
                function StripePayment(_session, _tutorService, builder, _router, _ngZone) {
                    var _this = this;
                    this._session = _session;
                    this._tutorService = _tutorService;
                    this.builder = builder;
                    this._router = _router;
                    this._ngZone = _ngZone;
                    this.submit_validate = false;
                    this.stripe_publish_key = '';
                    this.tutor_id = '';
                    this.trans_history = [];
                    this.sentStatus = "";
                    this.sentShow = false;
                    this.sentSuccessShow = false;
                    this.showClass = "";
                    this.credits = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
                    this.submit_disabled = false;
                    if (this._session.getCurrentId() == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        this.tutor_id = this._session.getCurrentId();
                        this.sentShow = false;
                        this.sentStatus = "";
                        this._tutorService.getStripeTransactionHistory({ tutor_id: this.tutor_id }).subscribe(function (res) {
                            _this.trans_history = res;
                        });
                        this.card_holder = new common_1.Control('', common_1.Validators.required);
                        this.email = new common_1.Control('', common_1.Validators.required);
                        this.card_number = new common_1.Control('', common_1.Validators.required);
                        this.amount = new common_1.Control('', common_1.Validators.required);
                        this.expire_month = new common_1.Control('', common_1.Validators.compose([common_1.Validators.required, common_1.Validators.maxLength(2)]));
                        this.expire_year = new common_1.Control('', common_1.Validators.compose([common_1.Validators.required, common_1.Validators.maxLength(2)]));
                        this.card_cvv = new common_1.Control('', common_1.Validators.compose([common_1.Validators.required, common_1.Validators.minLength(3), common_1.Validators.maxLength(4)]));
                        this.stripe_form = builder.group({
                            card_holder: this.card_holder,
                            email: this.email,
                            card_number: this.card_number,
                            amount: this.amount,
                            expire_month: this.expire_month,
                            expire_year: this.expire_year,
                            card_cvv: this.card_cvv
                        });
                    }
                }
                StripePayment.prototype.isNumberKey = function (evt) {
                    evt = (evt) ? evt : window.event;
                    var charCode = (evt.which) ? evt.which : evt.keyCode;
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    return true;
                };
                StripePayment.prototype.isCreditNumber = function (event, form) {
                    event = (event) ? event : window.event;
                    var charCode = (event.which) ? event.which : event.keyCode;
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    var val = form.card_number;
                    if (val.length >= 19 && charCode != 8)
                        return false;
                    var newval = '';
                    val = val.replace(/\D+/g, '');
                    for (var i = 0; i < val.length; i++) {
                        if (i % 4 == 0 && i > 0)
                            newval = newval.concat(" ");
                        newval = newval.concat(val[i]);
                    }
                    this.stripe_form.controls['card_number'].updateValue(newval);
                };
                StripePayment.prototype.isValidateEmail = function (email) {
                    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    return re.test(email);
                };
                StripePayment.prototype.getPaid = function (form) {
                    this.sentSuccessShow = false;
                    this.submit_validate = true;
                    if (this.stripe_form.valid && !this.validateExpireDate(form) && !this.validateCardNumber(form.card_number) && this.isValidateEmail(form.email)) {
                        this.getToken(form);
                    }
                };
                StripePayment.prototype.validateCardNumber = function (card_number) {
                    if (this.submit_validate == true && (card_number == '' || card_number == null || card_number.length != 19)) {
                        this.sentShow = true;
                        this.showClass = "alert alert-danger alert-dismissable";
                        this.sentStatus = "Your Card Number Must be Correct. Please type card number again";
                        return true;
                    }
                    this.sentShow = false;
                    return false;
                };
                StripePayment.prototype.validateExpireDate = function (form) {
                    var date = new Date();
                    if (this.submit_validate == true &&
                        ((Number(form.expire_year) < (date.getFullYear() - 2000)) ||
                            (Number(form.expire_year) == (date.getFullYear() - 2000) && Number(form.expire_month) < (date.getMonth())) ||
                            (Number(form.expire_year) > (date.getFullYear() - 2000) && Number(form.expire_month) > 12))) {
                        this.sentShow = true;
                        this.showClass = "alert alert-danger alert-dismissable";
                        this.sentStatus = "Expire Information Must be Correct. Please type expire month and year again";
                        return true;
                    }
                    this.sentShow = false;
                    return false;
                };
                StripePayment.prototype.getCreatedPaidDate = function (dateString) {
                    var date = new Date(dateString);
                    var options = {
                        weekday: "short", year: "numeric", month: "short",
                        day: "numeric", hour: "2-digit", minute: "2-digit"
                    };
                    return date.toLocaleTimeString("en-GB", options);
                };
                StripePayment.prototype.updateUI = function (flag, res) {
                    this.submit_disabled = false;
                    if (flag == true) {
                        this._session.setItem('creditcount', res.creditcount);
                        this.trans_history.unshift(res.trans);
                        this.sentSuccessShow = true;
                        this.showClass = "alert alert-success alert-dismissable";
                        this.sentStatus = "Your Payment has been successfully. You have got the new credits " + res.creditcount;
                    }
                    else {
                        this.sentSuccessShow = true;
                        this.showClass = "alert alert-danger alert-dismissable";
                        this.sentStatus = "Your Payment has not been failed. Please type your card information correctly!";
                    }
                };
                StripePayment.prototype.getToken = function (form) {
                    var _this = this;
                    this.submit_disabled = true;
                    var creditcount = this._session.getItem('creditcount');
                    this._tutorService.performPayment({ tutor_id: this.tutor_id, form: form, creditcount: creditcount }).subscribe(function (res) {
                        _this.updateUI(res.flag, res.data);
                    });
                };
                StripePayment.prototype.cancel = function () {
                    this._router.navigate(['TutorMain']);
                };
                StripePayment = __decorate([
                    core_1.Component({
                        selector: 'tutor-stripe-tutor',
                        templateUrl: '/components/tutor/stripe/tutor.html',
                        providers: [session_1.Session, tutor_1.TutorService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, tutor_1.TutorService, common_1.FormBuilder, router_1.Router, core_1.NgZone])
                ], StripePayment);
                return StripePayment;
            }());
            exports_1("StripePayment", StripePayment);
        }
    }
});
//# sourceMappingURL=tutor.js.map