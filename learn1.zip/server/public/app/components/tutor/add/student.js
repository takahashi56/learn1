System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/tutor', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, tutor_1, common_1;
    var AddTutorStudent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (tutor_1_1) {
                tutor_1 = tutor_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            AddTutorStudent = (function () {
                function AddTutorStudent(_session, _tutorService, builder, _router) {
                    this._session = _session;
                    this._tutorService = _tutorService;
                    this.builder = builder;
                    this._router = _router;
                    this.submitAttempt = false;
                    this.showGotoBack = false;
                    this.selectedNew = false;
                    this.selectedMonth = 0;
                    this.saving = false;
                    this.showNotSave = false;
                    this.months = ['Month', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
                    if (this._session.getCurrentId() == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        this.student = JSON.parse(this._session.getItem('TutorStudent'));
                        this.allStudentData = JSON.parse(this._session.getItem('TutorAllStudent'));
                        this.firstName = new common_1.Control(this.student.firstName, common_1.Validators.required);
                        this.lastName = new common_1.Control(this.student.lastName, common_1.Validators.required);
                        this.username = new common_1.Control(this.student.username);
                        this.phone = new common_1.Control(this.student.phone);
                        this.password = new common_1.Control(this.student.hashed_pwd, common_1.Validators.compose([common_1.Validators.required, common_1.Validators.minLength(6)]));
                        this.verifiedpassword = new common_1.Control(this.student.hashed_pwd, common_1.Validators.compose([common_1.Validators.required, common_1.Validators.minLength(6)]));
                        var _a = this.student.DOB.split('/'), day = _a[0], month = _a[1], year = _a[2];
                        this.selectedMonth = Number(month);
                        this.dob_day = new common_1.Control(day.trim());
                        this.dob_month = new common_1.Control(month);
                        this.dob_year = new common_1.Control(year.trim());
                        this.StudentForm = builder.group({
                            firstName: this.firstName,
                            lastName: this.lastName,
                            username: this.username,
                            dob_day: this.dob_day,
                            dob_month: this.dob_month,
                            dob_year: this.dob_year,
                            phone: this.phone,
                            password: this.password,
                            verifiedpassword: this.verifiedpassword
                        });
                        this.generatePassword();
                    }
                }
                AddTutorStudent.prototype.ngAfterViewInit = function () {
                    $("input.datepicker").datepicker({ dateFormat: 'dd/mm/yy' });
                };
                AddTutorStudent.prototype.generatePassword = function () {
                    var pwd = this.randomString();
                    if (this.student.hashed_pwd != '')
                        return;
                    this.StudentForm.controls['password'].updateValue(pwd);
                    this.StudentForm.controls['verifiedpassword'].updateValue(pwd);
                };
                AddTutorStudent.prototype.cancel = function () {
                    this._router.navigate(['TutorMain']);
                };
                AddTutorStudent.prototype.getValue = function (form) {
                    if (form.firstName == "" || form.lastName == "")
                        return '';
                    var firstName = form.firstName, lastName = form.lastName, username = firstName.charAt(0).toLowerCase() + lastName.toLowerCase(), i = 0;
                    if (this.allStudentData == null) {
                        i = 0;
                    }
                    else {
                        this.allStudentData.forEach(function (student) {
                            if (student.username.includes(username))
                                i++;
                        });
                    }
                    if (i != 0)
                        username = username + i;
                    this.StudentForm.controls['username'].updateValue(username);
                };
                AddTutorStudent.prototype.getUserName = function (form) {
                    var username = form.username.toLowerCase(), i = 0;
                    this.allStudentData.forEach(function (student) {
                        if (student.username.includes(username))
                            i++;
                    });
                    if (i != 0)
                        username = username + i;
                    this.StudentForm.controls['username'].updateValue(username);
                };
                AddTutorStudent.prototype.matchedPassword = function (form) {
                    var password = form.password, verifiedpassword = form.verifiedpassword;
                    if (password == verifiedpassword) {
                        return true;
                    }
                    else {
                        return false;
                    }
                };
                AddTutorStudent.prototype.validDob = function (form) {
                    if (form.dob_day == '' && Number(form.dob_month) == 0 && form.dob_year == '')
                        return true;
                    if (form.dob_day > 31)
                        return false;
                    if (form.dob_month > 12 || form.dob_month < 0)
                        return false;
                    if (form.dob_year.length < 4)
                        return false;
                    return true;
                };
                AddTutorStudent.prototype.AddStudent = function (form) {
                    var _this = this;
                    this.submitAttempt = true;
                    this.showNotSave = false;
                    if (this.StudentForm.valid && this.matchedPassword(form) && this.validDob(form) && this.checkIfEmailInString(form.username)) {
                        var dob = "";
                        if (form.dob_day == '' || Number(form.dob_day) == 0 || Number(form.dob_year) == 0 || Number(form.dob_month) == 0 || form.dob_month == '' || form.dob_year == '') {
                            dob = '';
                        }
                        else {
                            dob = (form.dob_day.length == 2 ? form.dob_day : '0' + form.dob_day) + "/" + (form.dob_month.length == 2 ? form.dob_month : '0' + form.dob_month) + "/" + form.dob_year;
                        }
                        var data = {
                            firstName: form.firstName,
                            lastName: form.lastName,
                            username: form.username,
                            DOB: dob,
                            hashed_pwd: form.password,
                            phone: form.phone,
                            isCompleted: false,
                            completedAt: '',
                            certificate: '',
                            tutor_id: this._session.getCurrentId()
                        };
                        var flag = JSON.parse(this._session.getItem('editORadd'));
                        if (flag.flag)
                            data["_id"] = this.student.student_id;
                        this.saving = true;
                        this._tutorService.addStudent(data, flag.flag)
                            .subscribe(function (res) {
                            _this.saving = false;
                            if (res.success) {
                                _this._router.navigate(['TutorMain']);
                            }
                            else {
                                _this.showNotSave = true;
                            }
                        });
                    }
                };
                AddTutorStudent.prototype.onKey = function (event) {
                    var value = event.target.value;
                    value = value.replace(/\D/g, '');
                    this.StudentForm.controls['phone'].updateValue(value);
                };
                AddTutorStudent.prototype.beforeGotoBack = function (form) {
                    if (form.firstName != this.student.firstName || form.lastName != this.student.lastName || form.username != this.student.username || form.phone != this.student.phone) {
                        this.showGotoBack = true;
                    }
                    else {
                        this.showGotoBack = false;
                        this.cancel();
                    }
                };
                AddTutorStudent.prototype.isNumberKey = function (evt) {
                    evt = (evt) ? evt : window.event;
                    var charCode = (evt.which) ? evt.which : evt.keyCode;
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    return true;
                };
                AddTutorStudent.prototype.isDayKey = function (evt, form) {
                    evt = (evt) ? evt : window.event;
                    var charCode = (evt.which) ? evt.which : evt.keyCode;
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    var val = form.dob_day == null ? '' : form.dob_day;
                    if (val.length < 2) {
                        val = val + (charCode - 48);
                    }
                    if (Number(val) > 31)
                        return false;
                    return true;
                };
                AddTutorStudent.prototype.isYearKey = function (evt, form) {
                    evt = (evt) ? evt : window.event;
                    var charCode = (evt.which) ? evt.which : evt.keyCode;
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    var val = form.dob_year == null ? '' : form.dob_year;
                    if (val.length < 4) {
                        val = val + (charCode - 48);
                    }
                    if (val.length == 4) {
                        if (Number(val) < 1916)
                            return false;
                    }
                    if (Number(val) > (new Date()).getFullYear())
                        return false;
                    return true;
                };
                AddTutorStudent.prototype.randomString = function () {
                    var length = 8, chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    var result = '';
                    for (var i = length; i > 0; --i)
                        result += chars[Math.floor(Math.random() * chars.length)];
                    return result;
                };
                AddTutorStudent.prototype.checkIfEmailInString = function (text) {
                    var re = /(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))/;
                    return re.test(text);
                };
                AddTutorStudent = __decorate([
                    core_1.Component({
                        selector: 'tutor-add-student',
                        templateUrl: '/components/tutor/add/student.html',
                        providers: [session_1.Session, tutor_1.TutorService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, tutor_1.TutorService, common_1.FormBuilder, router_1.Router])
                ], AddTutorStudent);
                return AddTutorStudent;
            }());
            exports_1("AddTutorStudent", AddTutorStudent);
        }
    }
});
//# sourceMappingURL=student.js.map