System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/tutor'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, tutor_1;
    var DetailTutorCourse;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (tutor_1_1) {
                tutor_1 = tutor_1_1;
            }],
        execute: function() {
            DetailTutorCourse = (function () {
                function DetailTutorCourse(_session, _tutorService, _router) {
                    var _this = this;
                    this._session = _session;
                    this._tutorService = _tutorService;
                    this._router = _router;
                    this.selectStudents = [];
                    this.show_un_assign = false;
                    if (this._session.getCurrentId() == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        this.course = JSON.parse(this._session.getItem('TutorCourse'));
                        this._tutorService.getStudentsByCourseId(this.course.course_id, this._session.getCurrentId()).subscribe(function (res) {
                            _this.studentList = res;
                        });
                    }
                }
                DetailTutorCourse.prototype.gotoTutorMain = function () {
                    this._router.navigate(['TutorMain']);
                };
                DetailTutorCourse.prototype.doLogin = function (form) {
                    // this._session.login(form.username, form.password);
                };
                DetailTutorCourse.prototype.getCourseName = function () {
                    return this.titleCase(this.course.coursetitle);
                };
                DetailTutorCourse.prototype.getComplete = function (flag) {
                    return flag ? 'Yes' : 'No';
                };
                DetailTutorCourse.prototype.titleCase = function (str) {
                    return str.split(' ').map(function (val) {
                        return val.charAt(0).toUpperCase() + val.substr(1).toLowerCase();
                    }).join(' ');
                };
                DetailTutorCourse.prototype.getCompleteDate = function (student) {
                    var date = student.completedAt, isCompleted = student.isCompleted;
                    if (date == null || date == '' || isCompleted == false)
                        return '';
                    var d = new Date(date), day = d.getDate().toString().length == 1 ? '0' + d.getDate() : d.getDate(), month = (d.getMonth() + 1).toString().length == 1 ? '0' + (d.getMonth() + 1) : (d.getMonth() + 1), datestring = day + "/" + month + "/" + d.getFullYear();
                    return datestring;
                };
                DetailTutorCourse.prototype.gotoCertificate = function (student) {
                    var _this = this;
                    if (student.isCompleted == false)
                        return false;
                    var self = this;
                    this._tutorService.getLessonsNameByCourseId({ course_id: this.course.course_id }).subscribe(function (res) {
                        var data = {
                            coursename: _this.course.coursetitle,
                            studentname: student.firstName + " " + student.lastName,
                            score: student.score,
                            completed_at: student.completedAt,
                            lessons: res.data.join(','),
                            organization: _this._session.getItem("organization")
                        };
                        self._session.setItem('certificate', JSON.stringify(data));
                        window.open('/#/certificate');
                        // self._router.navigateByUrl('/certificate');
                    });
                };
                DetailTutorCourse.prototype.checkStudent = function (event, object) {
                    if (event.currentTarget.checked) {
                        this.selectStudents.push(object.student_id);
                    }
                    else {
                        this.selectStudents = this.selectStudents.filter(function (o) {
                            return o != object.student_id;
                        });
                    }
                };
                DetailTutorCourse.prototype.unassign = function () {
                    var _this = this;
                    var student_ids = [];
                    this.show_un_assign = false;
                    if (this.selectStudents.length == 0)
                        return;
                    this.selectStudents.forEach(function (id) {
                        _this.studentList.forEach(function (student) {
                            if (student.student_id == id)
                                if (student.isCompleted == false) {
                                    student_ids.push(id);
                                }
                                else {
                                    _this.show_un_assign = true;
                                    return;
                                }
                        });
                    });
                    if (this.show_un_assign == false && student_ids.length != 0) {
                        this._tutorService.unAssign({ course_id: this.course.course_id, student_ids: student_ids, tutor_id: this._session.getCurrentId(), creditcount: Number(this._session.getItem('creditcount')) }).subscribe(function (res) {
                            _this.studentList = _this.studentList.filter(function (student) {
                                return !_this.selectStudents.includes(student.student_id);
                            });
                            _this.selectStudents = [];
                            _this._session.setItem('creditcount', res.creditcount);
                        });
                    }
                };
                DetailTutorCourse = __decorate([
                    core_1.Component({
                        selector: 'tutor-detail-course',
                        templateUrl: '/components/tutor/detail/course.html',
                        providers: [session_1.Session, tutor_1.TutorService],
                        directives: [router_1.ROUTER_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, tutor_1.TutorService, router_1.Router])
                ], DetailTutorCourse);
                return DetailTutorCourse;
            }());
            exports_1("DetailTutorCourse", DetailTutorCourse);
        }
    }
});
//# sourceMappingURL=course.js.map