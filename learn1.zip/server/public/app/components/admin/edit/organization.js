System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/admin', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, admin_1, common_1;
    var EditOrganization;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (admin_1_1) {
                admin_1 = admin_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            EditOrganization = (function () {
                function EditOrganization(_session, _adminService, builder, _router) {
                    this._session = _session;
                    this._adminService = _adminService;
                    this.builder = builder;
                    this._router = _router;
                    this.submitAttempt = false;
                    if (this._session.getCurrentId() == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        this.org = JSON.parse(this._session.getItem('org'));
                        this.firstName = new common_1.Control(this.org.firstName, common_1.Validators.required);
                        this.lastName = new common_1.Control(this.org.lastName, common_1.Validators.required);
                        this.organization = new common_1.Control(this.org.organization, common_1.Validators.required);
                        this.email = new common_1.Control(this.org.email, common_1.Validators.required);
                        this.password = new common_1.Control('', common_1.Validators.compose([common_1.Validators.required, common_1.Validators.minLength(6)]));
                        this.phone = new common_1.Control(this.org.phone);
                        this.notes = new common_1.Control(this.org.notes);
                        this.department = new common_1.Control(this.org.department);
                        this.OrganizeForm = builder.group({
                            firstName: this.firstName,
                            lastName: this.lastName,
                            organization: this.organization,
                            email: this.email,
                            phone: this.phone,
                            department: this.department,
                            password: this.password,
                            notes: this.notes
                        });
                    }
                }
                EditOrganization.prototype.cancel = function () {
                    this._router.navigate(['AdminMain']);
                };
                EditOrganization.prototype.isValidPassword = function (password) {
                    if (password == '')
                        return true;
                    if (password.length > 5)
                        return true;
                    return false;
                };
                EditOrganization.prototype.isNumberKey = function (evt) {
                    evt = (evt) ? evt : window.event;
                    var charCode = (evt.which) ? evt.which : evt.keyCode;
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    return true;
                };
                EditOrganization.prototype.update = function (form) {
                    var _this = this;
                    this.submitAttempt = true;
                    if (form.firstName != this.org.firstName || form.lastName != this.org.lastName || this.isValidPassword(form.password) || form.email != this.org.email || form.organization != this.org.organization || form.phone != this.org.phone || form.department != this.org.department || form.notes != this.org.notes) {
                        var data = {
                            _id: this.org.id,
                            firstName: form.firstName,
                            lastName: form.lastName,
                            organization: form.organization,
                            email: form.email,
                            password: form.password,
                            department: form.department,
                            phone: form.phone,
                            notes: form.notes
                        };
                        this._adminService.updateTutor(data)
                            .subscribe(function (res) {
                            if (res.success) {
                                _this._router.navigate(['AdminMain']);
                            }
                        });
                    }
                };
                EditOrganization = __decorate([
                    core_1.Component({
                        selector: 'admin-edit-organization',
                        templateUrl: '/components/admin/edit/organization.html',
                        providers: [session_1.Session, admin_1.AdminService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, admin_1.AdminService, common_1.FormBuilder, router_1.Router])
                ], EditOrganization);
                return EditOrganization;
            }());
            exports_1("EditOrganization", EditOrganization);
        }
    }
});
//# sourceMappingURL=organization.js.map