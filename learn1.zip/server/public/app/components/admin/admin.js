System.register(['angular2/core', 'angular2/router', './main/main', './add/course', './add/lesson', './add/question', './add/slide', './add/organization', './add/admin', './edit/lesson', './edit/course', './edit/admin', './edit/organization'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, main_1, course_1, lesson_1, question_1, slide_1, organization_1, admin_1, lesson_2, course_2, admin_2, organization_2;
    var Admin;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (main_1_1) {
                main_1 = main_1_1;
            },
            function (course_1_1) {
                course_1 = course_1_1;
            },
            function (lesson_1_1) {
                lesson_1 = lesson_1_1;
            },
            function (question_1_1) {
                question_1 = question_1_1;
            },
            function (slide_1_1) {
                slide_1 = slide_1_1;
            },
            function (organization_1_1) {
                organization_1 = organization_1_1;
            },
            function (admin_1_1) {
                admin_1 = admin_1_1;
            },
            function (lesson_2_1) {
                lesson_2 = lesson_2_1;
            },
            function (course_2_1) {
                course_2 = course_2_1;
            },
            function (admin_2_1) {
                admin_2 = admin_2_1;
            },
            function (organization_2_1) {
                organization_2 = organization_2_1;
            }],
        execute: function() {
            Admin = (function () {
                function Admin() {
                }
                Admin = __decorate([
                    core_1.Component({
                        selector: 'admin',
                        templateUrl: '/components/admin/admin.html',
                        directives: [router_1.ROUTER_DIRECTIVES, router_1.RouterOutlet]
                    }),
                    router_1.RouteConfig([
                        new router_1.Route({ path: '/main', component: main_1.Main, name: 'AdminMain', useAsDefault: true }),
                        new router_1.Route({ path: '/add/course', component: course_1.AddCourse, name: 'AdminAddCourse' }),
                        new router_1.Route({ path: '/add/lesson', component: lesson_1.AddLesson, name: 'AdminAddLesson' }),
                        new router_1.Route({ path: '/add/slide', component: slide_1.Slide, name: 'AdminAddSlide' }),
                        new router_1.Route({ path: '/add/question', component: question_1.Question, name: 'AdminAddQuestion' }),
                        new router_1.Route({ path: '/add/organization', component: organization_1.AddOrganization, name: 'AdminAddOrganization' }),
                        new router_1.Route({ path: '/add/admin', component: admin_1.AddAdmin, name: 'AdminAddAdmin' }),
                        new router_1.Route({ path: '/edit/course', component: course_2.EditCourse, name: 'AdminEditCourse' }),
                        new router_1.Route({ path: '/edit/lesson', component: lesson_2.EditLesson, name: 'AdminEditLesson' }),
                        new router_1.Route({ path: '/edit/admin', component: admin_2.EditAdmin, name: 'AdminEditAdmin' }),
                        new router_1.Route({ path: '/edit/organization', component: organization_2.EditOrganization, name: 'AdminEditOrganization' }),
                    ]), 
                    __metadata('design:paramtypes', [])
                ], Admin);
                return Admin;
            }());
            exports_1("Admin", Admin);
        }
    }
});
//# sourceMappingURL=admin.js.map