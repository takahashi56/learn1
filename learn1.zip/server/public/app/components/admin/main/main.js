System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/admin', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, admin_1, common_1;
    var Main;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (admin_1_1) {
                admin_1 = admin_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            // import * as moment from 'moment';
            Main = (function () {
                function Main(_session, _adminService, _router, builder) {
                    // var admin_id = this._session.getCurrentId(), role=this._session.getCurrentRole();
                    var _this = this;
                    this._session = _session;
                    this._adminService = _adminService;
                    this._router = _router;
                    this.builder = builder;
                    this.courseList = [];
                    this.orgList = [];
                    this.adminList = [];
                    this.coursesData = [];
                    this.lessonsData = [];
                    this.contentsData = [];
                    this.selectOrg = [];
                    this.selectCourse = [];
                    this.selectAdmin = [];
                    this.showRemoveOrg = false;
                    this.showRemoveCourse = false;
                    this.showRemoveAdmin = false;
                    this.stringRemoveOrg = '';
                    this.stringRemoveCourse = '';
                    this.stringRemoveAdmin = '';
                    this.validateoldconfirm = false;
                    this.validatenewconfirm = false;
                    this.changeSuccess = false;
                    this.showAlert = false;
                    this.validOldPassword = true;
                    this.matchedTrue = false;
                    this.failure = '';
                    this.course_tab = '';
                    this.org_tab = '';
                    this.admin_tab = '';
                    this.select_tab_item = 1;
                    // if(admin_id == '' || parseInt(role) != 0){
                    // 	this._router.navigate(['Login']);
                    // }
                    this.admin_id = this._session.getCurrentId();
                    if (this.admin_id == null) {
                        this._router.navigateByUrl('/home');
                    }
                    else {
                        this._adminService.getAllCourses().subscribe(function (res) {
                            _this.courseList = res;
                            var titles = [];
                            _this.courseList.forEach(function (c) {
                                titles.push(c.title);
                            });
                            _this._session.setItem('titles', JSON.stringify(titles));
                        });
                        this._adminService.getAllOrgs().subscribe(function (res) {
                            _this.orgList = res;
                        });
                        this._adminService.getAllAdmins({ admin_id: this.admin_id }).subscribe(function (res) {
                            _this.adminList = res;
                        });
                        this.oldpwd = new common_1.Control('', common_1.Validators.compose([common_1.Validators.required, common_1.Validators.minLength(6)]));
                        this.newpwd = new common_1.Control('', common_1.Validators.compose([common_1.Validators.required, common_1.Validators.minLength(6)]));
                        this.newpwdconfirm = new common_1.Control('', common_1.Validators.compose([common_1.Validators.required, common_1.Validators.minLength(6)]));
                        this.SettingForm = builder.group({
                            newpwd: this.newpwd,
                            newpwdconfirm: this.newpwdconfirm,
                            oldpwd: this.oldpwd
                        });
                        if (this._session.getItem('select_tab') == null) {
                            this.onTabClick(1);
                        }
                        else {
                            this.onTabClick(Number(this._session.getItem('select_tab')));
                        }
                    }
                }
                Main.prototype.ngAfterViewInit = function () {
                    setTimeout(function () {
                        window.dispatchEvent(new Event('resize'));
                    }, 10);
                };
                Main.prototype.editCourse = function (course) {
                    var _this = this;
                    var lessons = [];
                    this._adminService.getEditCourses(course.course_id).subscribe(function (res) {
                        _this._session.setItem('editORadd', JSON.stringify({ flag: true }));
                        var course = JSON.parse(_this._session.getItem('Course'));
                        if (course == null) {
                            _this._session.setItem('Course', JSON.stringify(res));
                        }
                        else if (course.course_id == res.course_id) {
                            _this._session.setItem('Course', JSON.stringify(course));
                        }
                        else {
                            _this._session.setItem('Course', JSON.stringify(res));
                        }
                        _this._router.navigate(['AdminAddCourse']);
                    });
                };
                Main.prototype.gotoEdit = function (org) {
                    this._session.setItem('org', JSON.stringify(org));
                    this._router.navigate(['AdminEditOrganization']);
                };
                Main.prototype.gotoEditAdmin = function (admin) {
                    this._session.setItem('admin', JSON.stringify(admin));
                    this._router.navigate(['AdminEditAdmin']);
                };
                Main.prototype.ngOnInit = function () {
                };
                Main.prototype.gotoAddCourse = function () {
                    var data = {
                        course_id: Date.now(),
                        coursetitle: '',
                        coursedescription: '',
                        draftORLive: false,
                        lesson: [],
                    };
                    this._session.setItem('editORadd', JSON.stringify({ flag: false }));
                    this._session.setItem('Course', JSON.stringify(data));
                    this._router.navigate(['AdminAddCourse']);
                };
                Main.prototype.removeCourse = function () {
                    var _this = this;
                    if (this.selectCourse.length == 0)
                        return false;
                    this.showRemoveCourse = false;
                    this._adminService.removeCourseById(this.selectCourse).subscribe(function (res) {
                        _this.selectCourse.map(function (id) {
                            _this.courseList = _this.courseList.filter(function (course) {
                                return course.course_id != id;
                            });
                        });
                        _this.selectCourse = [];
                    });
                };
                Main.prototype.removeOrg = function () {
                    var _this = this;
                    if (this.selectOrg.length == 0)
                        return false;
                    this.showRemoveOrg = false;
                    this._adminService.removeOrgById(this.selectOrg).subscribe(function (res) {
                        _this.selectOrg.map(function (id) {
                            _this.orgList = _this.orgList.filter(function (org) {
                                return org.id != id;
                            });
                        });
                        _this.selectOrg = [];
                    });
                };
                Main.prototype.removeAdmin = function () {
                    var _this = this;
                    if (this.selectAdmin.length == 0)
                        return false;
                    this.showRemoveAdmin = false;
                    this._adminService.removeAdminById(this.selectAdmin).subscribe(function (res) {
                        if (res.success == false) {
                            return;
                        }
                        else {
                            _this.selectAdmin.map(function (id) {
                                _this.adminList = _this.adminList.filter(function (admin) {
                                    return admin._id != id;
                                });
                            });
                            _this.selectAdmin = [];
                        }
                    });
                };
                Main.prototype.checkCourse = function (event, object) {
                    if (event.currentTarget.checked) {
                        this.selectCourse.push(object.course_id);
                    }
                    else {
                        this.selectCourse = this.selectCourse.filter(function (o) {
                            return o != object.course_id;
                        });
                    }
                };
                Main.prototype.checkOrganization = function (event, object) {
                    if (event.currentTarget.checked) {
                        this.selectOrg.push(object.id);
                    }
                    else {
                        this.selectOrg = this.selectOrg.filter(function (o) {
                            return o != object.id;
                        });
                    }
                };
                Main.prototype.checkAdmin = function (event, object) {
                    if (event.currentTarget.checked && this.admin_id != object._id) {
                        this.selectAdmin.push(object._id);
                    }
                    else {
                        this.selectAdmin = this.selectAdmin.filter(function (o) {
                            return o != object._id;
                        });
                    }
                };
                Main.prototype.beforeRemoveOrg = function () {
                    if (this.selectOrg.length == 0) {
                        this.showRemoveOrg = false;
                        return false;
                    }
                    if (this.selectOrg.length == 1) {
                        this.stringRemoveOrg = "Are you sure to remove this organization?";
                    }
                    else {
                        this.stringRemoveOrg = "Are you sure to remove these organizations?";
                    }
                    this.showRemoveOrg = true;
                };
                Main.prototype.beforeRemoveAdmin = function () {
                    if (this.selectAdmin.length == 0) {
                        this.showRemoveAdmin = false;
                        return false;
                    }
                    if (this.selectAdmin.length == 1) {
                        this.stringRemoveAdmin = "Are you sure to remove this administrator?";
                    }
                    else {
                        this.stringRemoveAdmin = "Are you sure to remove these administrators?";
                    }
                    this.showRemoveAdmin = true;
                };
                Main.prototype.beforeRemoveCourse = function () {
                    if (this.selectCourse.length == 0) {
                        this.showRemoveCourse = false;
                        return false;
                    }
                    if (this.selectCourse.length == 1) {
                        this.stringRemoveCourse = "Are you sure to remove this course?";
                    }
                    else {
                        this.stringRemoveCourse = "Are you sure to remove these courses?";
                    }
                    this.showRemoveCourse = true;
                };
                Main.prototype.matchedPassword = function (form) {
                    var password = form.newpwd, verifiedpassword = form.newpwdconfirm;
                    if (password == verifiedpassword) {
                        this.matchedTrue = true;
                        return true;
                    }
                    else {
                        this.matchedTrue = false;
                        return false;
                    }
                };
                Main.prototype.ChangePassowrd = function (form) {
                    var _this = this;
                    if (form.oldpwd == "" || form.oldpwd == null || this.validOldPassword == true) {
                        this.validateoldconfirm = true;
                        return;
                    }
                    this.validatenewconfirm = true;
                    if (this.SettingForm.valid && !this.matchedTrue) {
                        this.showAlert = true;
                        this.changeSuccess = false;
                        this.failure = 'The Password Must Be Matched';
                    }
                    if (this.SettingForm.valid && this.matchedTrue) {
                        var newPwd = form.newpwd;
                        this._adminService.changePassword({ admin_id: this.admin_id, pwd: newPwd }).subscribe(function (res) {
                            _this.showAlert = true;
                            if (res.success) {
                                _this.changeSuccess = true;
                            }
                            else {
                                _this.changeSuccess = false;
                                _this.failure = 'Your update have been failed.';
                            }
                        });
                    }
                };
                Main.prototype.blurChange = function (form) {
                    var oldPwd = form.oldpwd;
                    this.isValidOldPassword(oldPwd);
                };
                Main.prototype.onKey = function (event) {
                    if (event.keyCode !== 13)
                        return;
                    var value = event.target.value;
                    this.isValidOldPassword(value);
                };
                Main.prototype.isValidOldPassword = function (pwd) {
                    var _this = this;
                    this.validateoldconfirm = true;
                    this._adminService.isValidOldPassword({ admin_id: this.admin_id, pwd: pwd }).subscribe(function (res) {
                        if (res.success) {
                            _this.validOldPassword = false;
                        }
                        else {
                            _this.validOldPassword = true;
                            _this.validateoldconfirm = false;
                        }
                    });
                };
                Main.prototype.cancel = function (form) {
                    this.SettingForm.controls['oldpwd'].updateValue('');
                    this.SettingForm.controls['newpwd'].updateValue('');
                    this.SettingForm.controls['newpwdconfirm'].updateValue('');
                };
                Main.prototype.getCompleteDate = function (date) {
                    if (date == null || date == '')
                        return '';
                    var d = new Date(date), day = d.getDate().toString().length == 1 ? '0' + d.getDate() : d.getDate(), month = (d.getMonth() + 1).toString().length == 1 ? '0' + (d.getMonth() + 1) : (d.getMonth() + 1), datestring = day + "/" + month + "/" + d.getFullYear();
                    return datestring;
                };
                Main.prototype.check = function (control) {
                };
                Main.prototype.onTabClick = function (num) {
                    this.course_tab = "tab-pane";
                    this.org_tab = "tab-pane";
                    this.admin_tab = "tab-pane";
                    this._session.setItem('select_tab', num);
                    this.select_tab_item = num;
                    switch (num) {
                        case 1:
                            this.course_tab = "tab-pane active";
                            break;
                        case 2:
                            this.org_tab = "tab-pane active";
                            break;
                        case 3:
                            this.admin_tab = "tab-pane active";
                            break;
                        default:
                            break;
                    }
                };
                Main = __decorate([
                    core_1.Component({
                        selector: 'admin-main',
                        templateUrl: '/components/admin/main/main.html',
                        providers: [session_1.Session, admin_1.AdminService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES],
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, admin_1.AdminService, router_1.Router, common_1.FormBuilder])
                ], Main);
                return Main;
            }());
            exports_1("Main", Main);
        }
    }
});
//# sourceMappingURL=main.js.map