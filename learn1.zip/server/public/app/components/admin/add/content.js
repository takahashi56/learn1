System.register(['angular2/core', '../../../services/session', '../../../services/admin', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, admin_1, common_1;
    var LessonContent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (admin_1_1) {
                admin_1 = admin_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            LessonContent = (function () {
                function LessonContent(_session, builder, _adminService) {
                    this._session = _session;
                    this.builder = builder;
                    this._adminService = _adminService;
                    this.manageContent = new core_1.EventEmitter();
                    this.videoOrQuestion = false;
                    this.singleOrMulti = false;
                    this.questionType = false;
                    this.trueNumber = 0;
                    this.submitAttempt = false;
                }
                LessonContent.prototype.ngOnInit = function () {
                    this._content_id = this.content._content_id ? this.content._content_id : this.content._id;
                    this.videoOrQuestion = this.content.videoOrQuestion;
                    this.singleOrMulti = this.content.singleOrMulti;
                    this.questionType = this.content.questionType == true ? true : false;
                    this.image = this.content.image;
                    this.videoLabel = new common_1.Control(this.content.videoLabel, common_1.Validators.required);
                    this.videoEmbedCode = new common_1.Control(this.content.videoEmbedCode, common_1.Validators.required);
                    this.question = new common_1.Control(this.content.question, common_1.Validators.required);
                    this.answerA = new common_1.Control(this.content.answerA, common_1.Validators.required);
                    this.answerB = new common_1.Control(this.content.answerB, common_1.Validators.required);
                    this.answerC = new common_1.Control(this.content.answerC, common_1.Validators.required);
                    this.answerD = new common_1.Control(this.content.answerD, common_1.Validators.required);
                    this.trueNumber = this.content.trueNumber;
                    this.contentForm = this.builder.group({
                        videoLabel: this.videoLabel,
                        videoEmbedCode: this.videoEmbedCode,
                        question: this.question,
                        answerA: this.answerA,
                        answerB: this.answerB,
                        answerC: this.answerC,
                        answerD: this.answerD,
                        trueNumber: this.trueNumber,
                    });
                };
                LessonContent.prototype.choiceChange = function (flag) {
                    switch (flag) {
                        case 0:
                            this.questionType = false;
                            this.singleOrMulti = false;
                            break;
                        case 1:
                            this.questionType = false;
                            this.singleOrMulti = true;
                            break;
                        case 2:
                            this.questionType = true;
                            this.singleOrMulti = true;
                            break;
                        default:
                            break;
                    }
                };
                LessonContent.prototype.choiceAnswer = function (form, n) {
                    this.trueNumber = n;
                    this.blurChange(form);
                };
                LessonContent.prototype.removeContent = function () {
                    var original = JSON.parse(this._session.getItem('Content')), id = this._content_id;
                    if (original.length == 1)
                        return false;
                    original = original.filter(function (obj) {
                        var content_id = obj._content_id ? obj._content_id : obj._id;
                        return content_id !== id;
                    });
                    this._session.setItem('Content', JSON.stringify(original));
                    this.manageContent.emit(original);
                };
                LessonContent.prototype.blurChange = function (form) {
                    this.submitAttempt = true;
                    var original = JSON.parse(this._session.getItem('Content')), updated = true, original_copy = [];
                    if (this.videoOrQuestion) {
                        if (form.videoLabel != "" && form.videoEmbedCode != "")
                            updated = false;
                    }
                    else {
                        switch (this.singleOrMulti) {
                            case false:
                                if (form.question != "")
                                    updated = false;
                                break;
                            case true:
                                if (form.question == "" || form.answerA == "" || form.answerB == "" || form.answerC == "" || form.answerD == "" || this.trueNumber == 0 || (this.questionType && this.image == null)) {
                                    updated = true;
                                }
                                else {
                                    updated = false;
                                }
                                break;
                            default:
                                updated = true;
                                break;
                        }
                    }
                    if (!updated) {
                        this.content.videoLabel = form.videoLabel;
                        this.content.videoEmbedCode = form.videoEmbedCode;
                        this.content.question = form.question;
                        this.content.image = this.image;
                        this.content.questionType = this.questionType;
                        this.content.singleOrMulti = this.singleOrMulti;
                        this.content.answerA = form.answerA;
                        this.content.answerB = form.answerB;
                        this.content.answerC = form.answerC;
                        this.content.answerD = form.answerD;
                        this.content.trueNumber = this.trueNumber;
                        var data = this.content;
                        original.forEach(function (obj) {
                            var first_id = obj._content_id ? obj._content_id : obj._id;
                            var second_id = data._content_id ? data._content_id : data._id;
                            if ((first_id == second_id)) {
                                original_copy.push(data);
                            }
                            else {
                                original_copy.push(obj);
                            }
                        });
                        this._session.setItem('Content', JSON.stringify(original_copy));
                        this.manageContent.emit(original_copy);
                    }
                };
                LessonContent.prototype.addQuestionOrVideo = function (form, flag) {
                    this.submitAttempt = true;
                    var original = JSON.parse(this._session.getItem('Content')), updated = true, original_copy = [];
                    if (this.videoOrQuestion) {
                        if (form.videoLabel != "" && form.videoEmbedCode != "")
                            updated = false;
                    }
                    else {
                        switch (this.singleOrMulti) {
                            case false:
                                if (form.question != "")
                                    updated = false;
                                break;
                            case true:
                                if (form.question == "" || form.answerA == "" || form.answerB == "" || form.answerC == "" || form.answerD == "" || (this.questionType && this.image == "")) {
                                    updated = true;
                                }
                                else {
                                    updated = false;
                                }
                                break;
                            default:
                                updated = true;
                                break;
                        }
                    }
                    if (!updated) {
                        this.content.videoLabel = form.videoLabel;
                        this.content.videoEmbedCode = form.videoEmbedCode;
                        this.content.question = form.question;
                        this.content.questionType = this.questionType;
                        this.content.image = this.image;
                        this.content.singleOrMulti = this.singleOrMulti;
                        this.content.answerA = form.answerA;
                        this.content.answerB = form.answerB;
                        this.content.answerC = form.answerC;
                        this.content.answerD = form.answerD;
                        this.content.trueNumber = this.trueNumber;
                        var data = this.content;
                        var new_data = {
                            _content_id: (Date.now()).toString(),
                            videoOrQuestion: flag,
                            questionType: false,
                            videoLabel: '',
                            videoEmbedCode: '',
                            singleOrMulti: false,
                            question: '',
                            answerA: '',
                            answerB: '',
                            answerC: '',
                            answerD: '',
                            image: '',
                            trueNumber: '',
                        };
                        original_copy = [];
                        original.forEach(function (obj) {
                            var first_id = obj._content_id ? obj._content_id : obj._id;
                            var second_id = data._content_id ? data._content_id : data._id;
                            if (first_id == second_id) {
                                original_copy.push(data);
                                original_copy.push(new_data);
                            }
                            else {
                                original_copy.push(obj);
                            }
                        });
                        this._session.setItem('Content', JSON.stringify(original_copy));
                        this.manageContent.emit(original_copy);
                    }
                };
                LessonContent.prototype.updateContent = function () {
                    this.addQuestionOrVideo(this.contentForm.value, true);
                };
                LessonContent.prototype.onFileChange = function (event, form) {
                    var _this = this;
                    var files = event.srcElement.files;
                    this._adminService.upload(files).subscribe(function (res) {
                        _this.image = res.image;
                        _this.blurChange(form);
                    });
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Object)
                ], LessonContent.prototype, "content", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], LessonContent.prototype, "manageContent", void 0);
                LessonContent = __decorate([
                    core_1.Component({
                        selector: 'lesson-content',
                        templateUrl: '/components/admin/add/content.html',
                        providers: [session_1.Session, admin_1.AdminService],
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, common_1.FormBuilder, admin_1.AdminService])
                ], LessonContent);
                return LessonContent;
            }());
            exports_1("LessonContent", LessonContent);
        }
    }
});
//# sourceMappingURL=content.js.map