System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/admin', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, admin_1, common_1;
    var Question;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (admin_1_1) {
                admin_1 = admin_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            Question = (function () {
                function Question(_session, _adminService, builder, _router) {
                    this._session = _session;
                    this._adminService = _adminService;
                    this.builder = builder;
                    this._router = _router;
                    this.questionType = 1;
                    this.trueNumber = 0;
                    this.disableSubmit = false;
                    this.submitAttempt = false;
                    this.showTrueNumber = false;
                    this.data = JSON.parse(this._session.getItem('question'));
                    this.showTrueNumber = false;
                    this.questionName = new common_1.Control(this.data.label, common_1.Validators.required);
                    this.question = new common_1.Control(this.data.question, common_1.Validators.required);
                    this.answerA = new common_1.Control(this.data.answerA, common_1.Validators.required);
                    this.answerB = new common_1.Control(this.data.answerB, common_1.Validators.required);
                    this.answerC = new common_1.Control(this.data.answerC, common_1.Validators.required);
                    this.answerD = new common_1.Control(this.data.answerD, common_1.Validators.required);
                    this.answerText = new common_1.Control(this.data.answerText, common_1.Validators.required);
                    this.trueNumber = this.data.trueNumber;
                    this.image = this.data.image;
                    this.questionType = this.data.questionType;
                    this.questionForm = this.builder.group({
                        questionName: this.questionName,
                        question: this.question,
                        answerA: this.answerA,
                        answerB: this.answerB,
                        answerC: this.answerC,
                        answerD: this.answerD,
                        answerText: this.answerText,
                    });
                }
                Question.prototype.cancel = function () {
                    this._router.navigate(['AdminAddLesson']);
                };
                Question.prototype.getCourseName = function () {
                    var course = JSON.parse(this._session.getItem('Course'));
                    if (course.coursetitle == "") {
                        return "Add Course";
                    }
                    else {
                        return course.coursetitle;
                    }
                };
                Question.prototype.getLessonName = function () {
                    var lessonData = JSON.parse(this._session.getItem('Lesson_new'));
                    if (lessonData.lessonname == "") {
                        return "Question Name";
                    }
                    else {
                        return lessonData.lessonname;
                    }
                };
                Question.prototype.choiceChange = function (flag) {
                    this.questionType = flag;
                };
                Question.prototype.choiceAnswer = function (n) {
                    this.trueNumber = n;
                };
                Question.prototype.onFileChange = function (event, form) {
                    var _this = this;
                    var files = event.srcElement.files;
                    this._adminService.upload(files).subscribe(function (res) {
                        _this.image = res.image;
                    });
                };
                Question.prototype.SubmitQuestion = function (form) {
                    this.submitAttempt = true;
                    this.disableSubmit = true;
                    this.showTrueNumber = false;
                    if (this.questionType != 0 && this.trueNumber == 0) {
                        this.disableSubmit = false;
                        if (form.questionName == '')
                            return;
                        this.showTrueNumber = true;
                        return;
                    }
                    if (!this.validQuestinForm(form))
                        return;
                    this.data.label = form.questionName;
                    this.data.question = form.question;
                    this.data.answerA = form.answerA;
                    this.data.answerB = form.answerB;
                    this.data.answerC = form.answerC;
                    this.data.answerD = form.answerD;
                    this.data.answerText = form.answerText;
                    this.data.image = this.image;
                    this.data.questionType = this.questionType;
                    this.data.trueNumber = this.trueNumber;
                    var contents = JSON.parse(this._session.getItem('Content')), editAdd = JSON.parse(this._session.getItem('editAdd'));
                    if (editAdd == true) {
                        contents = this.updateArray(contents, this.data._id, this.data);
                    }
                    else {
                        contents.push(this.data);
                    }
                    this._session.setItem('Content', JSON.stringify(contents));
                    this._router.navigate(['AdminAddLesson']);
                };
                Question.prototype.updateArray = function (array, find, data) {
                    for (var i in array) {
                        if (array[i]._id == find) {
                            array[i].label = data.label;
                            array[i].question = data.question;
                            array[i].answerA = data.answerA;
                            array[i].answerB = data.answerB;
                            array[i].answerC = data.answerC;
                            array[i].answerD = data.answerD;
                            array[i].answerText = data.answerText;
                            array[i].trueNumber = data.trueNumber;
                            array[i].questionType = data.questionType;
                            array[i].image = data.image;
                            break; //Stop this loop, we found it!
                        }
                    }
                    return array;
                };
                Question.prototype.validQuestinForm = function (form) {
                    if (this.questionType == 0 && (form.answerText == '' || form.questionName == '')) {
                        return false;
                    }
                    if (this.questionType == 1 && (form.question == '' || form.questionName == '' || form.answerA == '' || form.answerB == '' || form.answerC == '' || form.answerD == '')) {
                        return false;
                    }
                    if (this.questionType == 2 && (form.question == '' || form.questionName == '' || form.answerA == '' || form.answerB == '' || form.answerC == '' || form.answerD == '' || this.image == '')) {
                        return false;
                    }
                    return true;
                };
                Question = __decorate([
                    core_1.Component({
                        selector: 'admin-add-question',
                        templateUrl: '/components/admin/add/question.html',
                        providers: [session_1.Session, admin_1.AdminService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, admin_1.AdminService, common_1.FormBuilder, router_1.Router])
                ], Question);
                return Question;
            }());
            exports_1("Question", Question);
        }
    }
});
//# sourceMappingURL=question.js.map