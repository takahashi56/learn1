System.register(['angular2/core'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var TinyEditor;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            TinyEditor = (function () {
                function TinyEditor(elementRef) {
                    this.valueChange = new core_1.EventEmitter();
                    this.elementRef = elementRef;
                    var randLetter = String.fromCharCode(65 + Math.floor(Math.random() * 26));
                    var uniqid = randLetter + Date.now();
                    this.elementID = 'tinymce' + uniqid;
                    this.valueChange = new core_1.EventEmitter();
                }
                TinyEditor.prototype.ngOnInit = function () {
                    this.htmlContent = this.value;
                    var that = this;
                    var baseTextArea = this.elementRef.nativeElement.querySelector("#baseTextArea");
                    var clonedTextArea = baseTextArea.cloneNode(true);
                    clonedTextArea.id = this.elementID;
                    var formGroup = this.elementRef.nativeElement.querySelector("#tinyFormGroup");
                    formGroup.appendChild(clonedTextArea);
                    tinymce.init({
                        selector: 'textarea',
                        height: 500,
                        theme: 'modern',
                        plugins: [
                            'advlist autolink lists link image charmap print preview hr anchor pagebreak',
                            'searchreplace wordcount visualblocks visualchars code fullscreen',
                            'insertdatetime media nonbreaking save table contextmenu directionality',
                            'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
                        ],
                        toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
                        toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
                        image_advtab: true,
                        templates: [
                            { title: 'Test template 1', content: 'Test 1' },
                            { title: 'Test template 2', content: 'Test 2' }
                        ],
                        content_css: [
                            '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                            '//www.tinymce.com/css/codepen.min.css'
                        ],
                        elements: this.elementID,
                        setup: this.tinyMCESetup.bind(this)
                    });
                    tinymce.get(this.elementID).setContent(this.value);
                };
                TinyEditor.prototype.tinyMCESetup = function (ed) {
                    ed.on('keyup', this.tinyMCEOnKeyup.bind(this));
                    ed.on('click', this.tinyMCEOnKeyup.bind(this));
                    ed.on('NodeChange', this.tinyMCEOnKeyup.bind(this));
                    ed.on('change', this.tinyMCEOnKeyup.bind(this));
                };
                TinyEditor.prototype.tinyMCEOnKeyup = function (e) {
                    if (tinymce.get(this.elementID) == null)
                        return;
                    console.log(tinymce.get(this.elementID).getContent());
                    this.valueChange.emit(tinymce.get(this.elementID).getContent());
                };
                TinyEditor.prototype.onChanges = function (changes) {
                    if (tinymce.activeEditor)
                        tinymce.activeEditor.setContent(this.value);
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Object)
                ], TinyEditor.prototype, "value", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], TinyEditor.prototype, "valueChange", void 0);
                TinyEditor = __decorate([
                    core_1.Component({
                        selector: 'tiny-editor',
                        template: "\n    <div id=\"tinyFormGroup\" class=\"form-group\">\n      <div class=\"hidden\">\n          <textarea id=\"baseTextArea\">{{htmlContent}}</textarea>\n      </div>\n  </div>"
                    }), 
                    __metadata('design:paramtypes', [core_1.ElementRef])
                ], TinyEditor);
                return TinyEditor;
            }());
            exports_1("TinyEditor", TinyEditor);
        }
    }
});
//# sourceMappingURL=tinyeditor.js.map