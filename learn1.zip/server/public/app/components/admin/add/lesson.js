System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/admin', './content', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, admin_1, content_1, common_1;
    var AddLesson;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (admin_1_1) {
                admin_1 = admin_1_1;
            },
            function (content_1_1) {
                content_1 = content_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            AddLesson = (function () {
                function AddLesson(_session, _adminService, builder, _router) {
                    this._session = _session;
                    this._adminService = _adminService;
                    this.builder = builder;
                    this._router = _router;
                    this.submitAttempt = false;
                    this.lessonData = [];
                    this.contents = [];
                    this.position = 0;
                    this.selectContent = [];
                    this.show_remove_content = false;
                    this.stringRemoveContent = '';
                    this.show_warning = false;
                    this.show_not_save = false;
                    if (this._session.getCurrentId() == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        this.newInit(false);
                    }
                }
                AddLesson.prototype.manageContent = function (value) {
                    this.contents = value; //JSON.parse(this._session.getItem('Content'));
                };
                AddLesson.prototype.cancel = function () {
                    console.log('e');
                    this._session.setItem('Lesson_new', null);
                    this._session.setItem('Content', null);
                    this._router.navigate(['AdminAddCourse']);
                };
                AddLesson.prototype.beforeCancel = function () {
                    this.show_not_save = false;
                    var contents = JSON.parse(this._session.getItem('Content')), result = false;
                    contents.forEach(function (content) {
                        if (content._id.length < 15) {
                            result = true;
                        }
                    });
                    if (result) {
                        this.show_not_save = true;
                    }
                    else {
                        this.show_not_save = false;
                        this.cancel();
                    }
                };
                AddLesson.prototype.SubmitLesson = function (form) {
                    this.submitAttempt = true;
                    if (this.lessonForm.valid) {
                        this.handleData(form);
                        this._session.setItem('valid_input', 1);
                        this._router.navigate(['AdminAddCourse']);
                    }
                };
                AddLesson.prototype.addNextLesson = function (form) {
                    this.submitAttempt = true;
                    if (this.lessonForm.valid) {
                        this.handleData(form);
                        var data = [{
                                _id: (Date.now()).toString(),
                                slideOrQuestion: true,
                                questionType: 1,
                                label: '',
                                question: '',
                                answerA: '',
                                answerB: '',
                                answerC: '',
                                answerD: '',
                                answerText: '',
                                image: '',
                                trueNumber: '',
                                order: null
                            }];
                        var data1 = {
                            lesson_id: (Date.now()).toString(),
                            lessonname: '',
                            lessondescription: '',
                            content: data,
                            created_at: new Date()
                        };
                        this._session.setItem('Lesson_new', JSON.stringify(data1));
                        this._session.setItem('Content', JSON.stringify(data));
                        this.newInit(true);
                    }
                };
                AddLesson.prototype.handleData = function (form) {
                    var contentData = JSON.parse(this._session.getItem('Content'));
                    contentData.forEach(function (content, index, array) {
                        content.order = index;
                    });
                    var lesson = {
                        lesson_id: this.lesson_id,
                        lessonname: this.lessonForm.controls['lessonname'].value,
                        lessondescription: this.lessonForm.controls['lessondescription'].value,
                        content: contentData,
                        created_at: this.created_at
                    };
                    this.submitAttempt = false;
                    var course = JSON.parse(this._session.getItem('Course')), lessons_copy = [], update_lesson = false, lesson_original = [];
                    lesson_original = course.lesson;
                    lesson_original.forEach(function (obj) {
                        if (obj.lesson_id == lesson.lesson_id) {
                            update_lesson = true;
                            lessons_copy.push(lesson);
                        }
                        else {
                            lessons_copy.push(obj);
                        }
                    });
                    if (!update_lesson) {
                        lessons_copy.push(lesson);
                    }
                    course.lesson = lessons_copy;
                    this._session.setItem('Course', JSON.stringify(course));
                };
                AddLesson.prototype.newInit = function (flag) {
                    this.lessonData = JSON.parse(this._session.getItem('Lesson_new'));
                    this.created_at = this.lessonData.created_at;
                    this.lesson_id = this.lessonData.lesson_id;
                    this.contents = JSON.parse(this._session.getItem('Content')) || []; //this.lessonData.content;
                    console.log(this.contents);
                    console.log(this.contents.length);
                    this.position = this.contents.length;
                    if (!flag) {
                        this.lessonname = new common_1.Control(this.lessonData.lessonname, common_1.Validators.required);
                        this.lessondescription = new common_1.Control(this.lessonData.lessondescription, common_1.Validators.required);
                        this.lessonForm = this.builder.group({
                            lessonname: this.lessonname,
                            lessondescription: this.lessondescription,
                        });
                    }
                    else {
                        this.lessonForm.controls['lessonname'].updateValue(this.lessonData.lessonname);
                        this.lessonForm.controls['lessondescription'].updateValue(this.lessonData.lessondescription);
                    }
                };
                AddLesson.prototype.getCourseName = function () {
                    var course = JSON.parse(this._session.getItem('Course'));
                    if (course.coursetitle == "") {
                        return "Add Lesson";
                    }
                    else {
                        return course.coursetitle;
                    }
                };
                AddLesson.prototype.getLessonName = function () {
                    if (this.lessonData.lessonname == "") {
                        return "Lesson Name";
                    }
                    else {
                        return this.lessonData.lessonname;
                    }
                };
                AddLesson.prototype.addSlide = function (form) {
                    var data = {
                        _id: (Date.now()).toString(),
                        slideOrQuestion: true,
                        label: '',
                        slideContent: '',
                        questionType: 1,
                        question: '',
                        answerA: '',
                        answerB: '',
                        answerC: '',
                        answerD: '',
                        answerText: '',
                        image: '',
                        trueNumber: '',
                        order: null
                    };
                    this.setTitleAndDesc(form);
                    this._session.setItem('editAdd', false);
                    this._session.setItem('slide', JSON.stringify(data));
                    this._router.navigate(['AdminAddSlide']);
                };
                AddLesson.prototype.addQuestion = function (form) {
                    var data = {
                        _id: (Date.now()).toString(),
                        slideOrQuestion: false,
                        label: '',
                        slideContent: '',
                        questionType: 1,
                        question: '',
                        answerA: '',
                        answerB: '',
                        answerC: '',
                        answerD: '',
                        answerText: '',
                        image: '',
                        trueNumber: 0,
                        order: null
                    };
                    this.setTitleAndDesc(form);
                    this._session.setItem('editAdd', false);
                    this._session.setItem('question', JSON.stringify(data));
                    this._router.navigate(['AdminAddQuestion']);
                };
                AddLesson.prototype.setTitleAndDesc = function (form) {
                    var lessonData = JSON.parse(this._session.getItem('Lesson_new'));
                    lessonData.lessonname = form.lessonname;
                    lessonData.lessondescription = form.lessondescription;
                    this._session.setItem('Lesson_new', JSON.stringify(lessonData));
                };
                AddLesson.prototype.gotoEditContent = function (content, form) {
                    this._session.setItem('editAdd', true);
                    this.setTitleAndDesc(form);
                    if (content.slideOrQuestion == true) {
                        this._session.setItem('slide', JSON.stringify(content));
                        this._router.navigate(['AdminAddSlide']);
                    }
                    else {
                        this._session.setItem('question', JSON.stringify(content));
                        this._router.navigate(['AdminAddQuestion']);
                    }
                };
                AddLesson.prototype.beforeRemoveContent = function () {
                    if (this.selectContent.length == 0) {
                        this.show_remove_content = false;
                        return false;
                    }
                    if (this.selectContent.length == 1) {
                        this.stringRemoveContent = "Are you sure to remove this content?";
                    }
                    else {
                        this.stringRemoveContent = "Are you sure to remove these contents?";
                    }
                    this.show_remove_content = true;
                };
                AddLesson.prototype.removeContent = function () {
                    var _this = this;
                    if (this.selectContent.length == 0)
                        return false;
                    this.show_remove_content = false;
                    this.selectContent.map(function (id) {
                        _this.contents = _this.contents.filter(function (content) {
                            return content._id != id;
                        });
                    });
                    this.selectContent = [];
                    this.position = this.contents.length;
                    this._session.setItem('Content', JSON.stringify(this.contents));
                };
                AddLesson.prototype.checkContent = function (event, object) {
                    if (event.currentTarget.checked) {
                        this.selectContent.push(object._id);
                    }
                    else {
                        this.selectContent = this.selectContent.filter(function (o) {
                            return o != object._id;
                        });
                    }
                };
                AddLesson.prototype.changePosition = function (num) {
                    var _this = this;
                    this.show_warning = false;
                    if (this.selectContent.length == 0)
                        return;
                    if (this.selectContent.length != 1) {
                        this.show_warning = true;
                        return;
                    }
                    var value = this.contents.filter(function (content) {
                        return content._id == _this.selectContent[0];
                    });
                    this.contents = this.moveElementInArray(this.contents, value[0], num - 1);
                    this._session.setItem('Content', JSON.stringify(this.contents));
                };
                AddLesson.prototype.isValidPosition = function () {
                    if (this.position == 0)
                        return false;
                    return true;
                };
                AddLesson.prototype.range = function (num) {
                    var a = [];
                    for (var i = 0; i < num; ++i) {
                        a.push(i + 1);
                    }
                    return a;
                };
                AddLesson.prototype.moveElementInArray = function (array, value, positionChange) {
                    var oldIndex = array.indexOf(value);
                    return this.move(array, oldIndex, positionChange);
                };
                AddLesson.prototype.move = function (array, from, to) {
                    array.splice(to, 0, array.splice(from, 1)[0]);
                    return array;
                };
                ;
                AddLesson = __decorate([
                    core_1.Component({
                        selector: 'admin-add-lesson',
                        templateUrl: '/components/admin/add/lesson.html',
                        providers: [session_1.Session, admin_1.AdminService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES, content_1.LessonContent]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, admin_1.AdminService, common_1.FormBuilder, router_1.Router])
                ], AddLesson);
                return AddLesson;
            }());
            exports_1("AddLesson", AddLesson);
        }
    }
});
//# sourceMappingURL=lesson.js.map