System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/admin', './tinyeditor', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, admin_1, tinyeditor_1, common_1;
    var Slide;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (admin_1_1) {
                admin_1 = admin_1_1;
            },
            function (tinyeditor_1_1) {
                tinyeditor_1 = tinyeditor_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            Slide = (function () {
                function Slide(_session, _adminService, builder, _router) {
                    this._session = _session;
                    this._adminService = _adminService;
                    this.builder = builder;
                    this._router = _router;
                    this.submitAttempt = false;
                    this.isValidContent = false;
                    this.disableSubmit = false;
                    this.data = JSON.parse(this._session.getItem('slide'));
                    this.slideName = new common_1.Control(this.data.label, common_1.Validators.required);
                    this.slideForm = this.builder.group({
                        slideName: this.slideName,
                    });
                }
                Slide.prototype.cancel = function () {
                    this._router.navigate(['AdminAddLesson']);
                };
                Slide.prototype.getCourseName = function () {
                    var course = JSON.parse(this._session.getItem('Course'));
                    if (course.coursetitle == "") {
                        return "Add Slide";
                    }
                    else {
                        return course.coursetitle;
                    }
                };
                Slide.prototype.getLessonName = function () {
                    var lessonData = JSON.parse(this._session.getItem('Lesson_new'));
                    if (lessonData.lessonname == "") {
                        return "Lesson Name";
                    }
                    else {
                        return lessonData.lessonname;
                    }
                };
                Slide.prototype.SubmitSlide = function (form) {
                    this.submitAttempt = true;
                    if (this.data.slideContent == "") {
                        this.isValidContent = true;
                    }
                    else {
                        this.isValidContent = false;
                    }
                    if (this.slideForm.valid && this.data.slideContent != '') {
                        this.isValidContent = false;
                        this.disableSubmit = true;
                        this.data.label = form.slideName;
                        var contents = JSON.parse(this._session.getItem('Content')), editAdd = JSON.parse(this._session.getItem('editAdd'));
                        if (editAdd == true) {
                            contents = this.updateArray(contents, this.data._id, this.data.slideContent, this.data.label);
                        }
                        else {
                            contents.push(this.data);
                        }
                        this._session.setItem('Content', JSON.stringify(contents));
                        this._router.navigate(['AdminAddLesson']);
                    }
                };
                Slide.prototype.updateArray = function (array, find, value, label) {
                    for (var i in array) {
                        if (array[i]._id == find) {
                            array[i].slideContent = value;
                            array[i].label = label;
                            break; //Stop this loop, we found it!
                        }
                    }
                    return array;
                };
                Slide = __decorate([
                    core_1.Component({
                        selector: 'admin-add-slide',
                        templateUrl: '/components/admin/add/slide.html',
                        providers: [session_1.Session, admin_1.AdminService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES, tinyeditor_1.TinyEditor]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, admin_1.AdminService, common_1.FormBuilder, router_1.Router])
                ], Slide);
                return Slide;
            }());
            exports_1("Slide", Slide);
        }
    }
});
//# sourceMappingURL=slide.js.map