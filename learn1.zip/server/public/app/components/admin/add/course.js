System.register(['angular2/core', '../../../services/session', 'angular2/router', '../../../services/admin', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, admin_1, common_1;
    var AddCourse;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (admin_1_1) {
                admin_1 = admin_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            AddCourse = (function () {
                function AddCourse(_session, _adminService, builder, _router) {
                    this._session = _session;
                    this._adminService = _adminService;
                    this.builder = builder;
                    this._router = _router;
                    this.submitAttempt = false;
                    this.courseData = {};
                    this.lessonData = [];
                    this.show_back = false;
                    this.showMessage = false;
                    this.titles = [];
                    this.showClass = "alert alert-danger alert-dismissable";
                    this.show_remove_lesson = false;
                    this.stringRemoveLesson = '';
                    this.selectLesson = [];
                    this.showText = '';
                    this.draftORLive = false;
                    this.show_not_save = false;
                    if (this._session.getCurrentId() == null) {
                        this._router.navigateByUrl('/login');
                    }
                    else {
                        this.courseData = JSON.parse(this._session.getItem('Course'));
                        this.coursetitle = new common_1.Control(this.courseData.coursetitle, common_1.Validators.required);
                        this.coursedescription = new common_1.Control(this.courseData.coursedescription, common_1.Validators.required);
                        this.lessonData = this.courseData.lesson;
                        this.show_remove_lesson = false;
                        this.titles = JSON.parse(this._session.getItem('titles'));
                        this.draftORLive = this.courseData.draftORLive;
                        this.courseForm = builder.group({
                            coursetitle: this.coursetitle,
                            coursedescription: this.coursedescription,
                        });
                    }
                }
                AddCourse.prototype.cancel = function () {
                    this._session.setItem('Course', null);
                    this._router.navigate(['AdminMain']);
                };
                AddCourse.prototype.beforeCancel = function (form) {
                    this.show_not_save = false;
                    var lessons = this.lessonData, result = false;
                    lessons.forEach(function (lesson) {
                        lesson.content.forEach(function (content) {
                            if (content._id.length < 15) {
                                result = true;
                            }
                        });
                    });
                    if (result || form.coursetitle != this.courseData.coursetitle || form.coursedescription != this.courseData.coursedescription) {
                        this.show_not_save = true;
                    }
                    else {
                        this.show_not_save = false;
                        this.cancel();
                    }
                };
                AddCourse.prototype.showBack = function (form) {
                    var data = JSON.parse(this._session.getItem('Course')), flag = false;
                    data.lesson.forEach(function (lesson) {
                        if (lesson.lesson_id.length < 14) {
                            flag = true;
                            return;
                        }
                    });
                    if (flag || form.coursetitle != this.courseData.coursetitle || form.coursedescription != this.courseData.coursedescription) {
                        this.show_back = true;
                    }
                    else {
                        this.cancel();
                    }
                };
                AddCourse.prototype.getVideoCount = function (lesson) {
                    var count = 0;
                    lesson.content.forEach(function (obj) {
                        if (obj.videoOrQuestion)
                            count++;
                    });
                    return count;
                };
                AddCourse.prototype.gotoEditLesson = function (lesson) {
                    this._session.setItem('Lesson_new', JSON.stringify(lesson));
                    this._session.setItem('Content', JSON.stringify(lesson.content));
                    this._router.navigate(['AdminAddLesson']);
                };
                AddCourse.prototype.addLesson = function (form) {
                    var data2 = {
                        course_id: this.courseData.course_id,
                        coursetitle: this.courseForm.controls["coursetitle"].value,
                        coursedescription: this.courseForm.controls["coursedescription"].value,
                        lesson: this.courseData.lesson,
                    };
                    var data = [];
                    var data1 = {
                        lesson_id: (Date.now()).toString(),
                        lessonname: '',
                        lessondescription: '',
                        content: data,
                        created_at: new Date()
                    };
                    this._session.setItem('Course', JSON.stringify(data2));
                    this._session.setItem('Lesson_new', JSON.stringify(data1));
                    this._session.setItem('Content', JSON.stringify(data));
                    this._router.navigate(['AdminAddLesson']);
                };
                AddCourse.prototype.SubmitCourse = function (form) {
                    var _this = this;
                    this.submitAttempt = true;
                    var editORadd = JSON.parse(this._session.getItem('editORadd'));
                    if (this.courseForm.valid && !this.validTitle(form.coursetitle)) {
                        var data = JSON.parse(this._session.getItem('Course'));
                        data.coursetitle = form.coursetitle;
                        data.coursedescription = form.coursedescription;
                        data['draftORLive'] = this.draftORLive || false;
                        // if(data.lesson.length == 0) return false;
                        this._adminService.addCourse(data, editORadd.flag)
                            .subscribe(function (res) {
                            if (res.success) {
                                _this._session.setItem('Course', null);
                                _this._session.setItem('Lesson_new', null);
                                _this._session.setItem('Content', null);
                                _this._router.navigate(['AdminMain']);
                            }
                            else {
                                console.log("");
                            }
                        });
                    }
                    else {
                        this.showMessage = true;
                        if (!this.courseForm.valid) {
                            this.showText = "This fields are required!";
                            return;
                        }
                        if (this.validTitle(form.coursetitle)) {
                            this.showText = "This course name was already used. Please provide another name.";
                            return;
                        }
                    }
                };
                AddCourse.prototype.getCourseName = function () {
                    if (this.courseData.coursetitle != "") {
                        return this.courseData.coursetitle;
                    }
                    else {
                        return "Add Course";
                    }
                };
                AddCourse.prototype.beforeRemoveLesson = function () {
                    if (this.selectLesson.length == 0) {
                        this.show_remove_lesson = false;
                        return false;
                    }
                    if (this.selectLesson.length == 1) {
                        this.stringRemoveLesson = "Are you sure to remove this lesson?";
                    }
                    else {
                        this.stringRemoveLesson = "Are you sure to remove these lessons?";
                    }
                    this.show_remove_lesson = true;
                };
                AddCourse.prototype.removeLesson = function () {
                    var _this = this;
                    if (this.selectLesson.length == 0)
                        return false;
                    this.show_remove_lesson = false;
                    this.selectLesson.map(function (id) {
                        _this.lessonData = _this.lessonData.filter(function (lesson) {
                            return lesson.lesson_id != id;
                        });
                    });
                    this.selectLesson = [];
                    this.courseData.lesson = this.lessonData;
                    var data = JSON.parse(this._session.getItem('Course'));
                    data.lesson = this.lessonData;
                    this._session.setItem('Course', JSON.stringify(data));
                };
                AddCourse.prototype.checkLesson = function (event, object) {
                    if (event.currentTarget.checked) {
                        this.selectLesson.push(object.lesson_id);
                    }
                    else {
                        this.selectLesson = this.selectLesson.filter(function (o) {
                            return o != object.lesson_id;
                        });
                    }
                };
                AddCourse.prototype.inputFocus = function () {
                    this.showMessage = false;
                };
                AddCourse.prototype.validTitle = function (course_title) {
                    if (course_title == this.courseData.coursetitle && course_title != '')
                        return false;
                    if (course_title == '')
                        return true;
                    return this.titles.includes(course_title) == true;
                };
                AddCourse.prototype.choiceChange = function (flag) {
                    this.draftORLive = flag;
                };
                AddCourse = __decorate([
                    core_1.Component({
                        selector: 'admin-add-course',
                        templateUrl: '/components/admin/add/course.html',
                        providers: [session_1.Session, admin_1.AdminService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, admin_1.AdminService, common_1.FormBuilder, router_1.Router])
                ], AddCourse);
                return AddCourse;
            }());
            exports_1("AddCourse", AddCourse);
        }
    }
});
//# sourceMappingURL=course.js.map