System.register(['angular2/core', '../../services/session', 'angular2/router', '../../services/authentication', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, authentication_1, common_1;
    var Forgetpwd;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (authentication_1_1) {
                authentication_1 = authentication_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            Forgetpwd = (function () {
                function Forgetpwd(_session, _adminService, builder) {
                    this._session = _session;
                    this._adminService = _adminService;
                    this.builder = builder;
                    this.sentStatus = "";
                    this.sentShow = false;
                    this.showClass = "";
                    this.submitAttempt = false;
                    this.sentShow = false;
                    this.sentStatus = "";
                    this.email = new common_1.Control('', common_1.Validators.required);
                    this.button_name = 'Reset';
                    this.ForgetpwdForm = builder.group({
                        email: this.email,
                    });
                }
                Forgetpwd.prototype.doLogin = function (form) {
                    // this._session.login(form.username, form.password);
                };
                Forgetpwd.prototype.Forgetpwd = function (form) {
                    var _this = this;
                    this.submitAttempt = true;
                    if (this.ForgetpwdForm.valid) {
                        this._adminService.forgetpwd({ email: form.email }).subscribe(function (res) {
                            _this.sentShow = true;
                            if (res.success) {
                                _this.showClass = "alert alert-success alert-dismissable";
                                _this.sentStatus = "An email containing instructions to reset your password has been sent to " + form.email + ".\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n\n\t\t\t\t\t\t\t\t\t\t\t\t\t\tif you did not receive the email, please contact us to recover your account.";
                                // this._session.setUser(form.email, null, "");
                                _this._session.setItem('forget_user', form.email);
                                _this.button_name = 'Sent';
                            }
                            else if (res.success == false && res.status != 500) {
                                _this.showClass = "alert alert-danger alert-dismissable";
                                _this.sentStatus = "This email was not sent. Please type the email correctly!";
                            }
                            else if (res.status == 500 && res.success == false) {
                                _this.showClass = "alert alert-danger alert-dismissable";
                                _this.sentStatus = "You tried to send to a recipient that has been marked as inactive. Please type the email correctly!";
                            }
                        });
                    }
                };
                Forgetpwd = __decorate([
                    core_1.Component({
                        selector: 'forget-pwd',
                        templateUrl: '/components/forgetpwd/forgetpwd.html',
                        providers: [session_1.Session, authentication_1.AuthService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, authentication_1.AuthService, common_1.FormBuilder])
                ], Forgetpwd);
                return Forgetpwd;
            }());
            exports_1("Forgetpwd", Forgetpwd);
        }
    }
});
//# sourceMappingURL=forgetpwd.js.map