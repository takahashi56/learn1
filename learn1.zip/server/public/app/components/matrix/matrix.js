System.register(['angular2/core', '../../services/session', 'angular2/router', '../../services/tutor'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, tutor_1;
    var Matrix;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (tutor_1_1) {
                tutor_1 = tutor_1_1;
            }],
        execute: function() {
            Matrix = (function () {
                function Matrix(_session, _tutorService, _router) {
                    this._session = _session;
                    this._tutorService = _tutorService;
                    this._router = _router;
                    this.organization = '';
                    if (this._session.getCurrentId() == null || this._session.getCurrentUser() == null) {
                        this._router.navigate(['Login']);
                    }
                    else {
                        this.organization = this._session.getItem('organization');
                        this.courseList = JSON.parse(this._session.getItem('courseList'));
                        var tutor_id = this._session.getCurrentId();
                        this.studentList = JSON.parse(this._session.getItem('studentList'));
                    }
                }
                Matrix.prototype.ngAfterViewInit = function () {
                    $(this.el.nativeElement).bootgrid({
                        navigation: 0,
                        rowCount: -1
                    });
                    this.downloadpdf();
                };
                Matrix.prototype.downloadpdf = function () {
                    var self = this;
                    html2canvas(document.getElementById('pdffromHtml'), {
                        onrendered: function (canvas) {
                            var ctx = canvas.getContext("2d");
                            var data = canvas.toDataURL("image/png", 1.5);
                            var docDefinition = {
                                content: [{
                                        image: data,
                                        width: 520,
                                    }]
                            };
                            var para = document.getElementById("editor"), para1 = document.createElement("div"), image = document.createElement("img"), image1 = document.createElement('img');
                            image.src = data;
                            para.appendChild(image);
                            // self.makeHighResScreenshot(image, image1, 200);
                            // para1.appendChild(image);
                            self._tutorService.makePdf({ data: para.innerHTML, direction: false }).subscribe(function (res) {
                                window.location.href = '/pdf-viewer/web/viewer.html?file=/pdf/' + res.url;
                            });
                        }
                    });
                };
                Matrix.prototype.getCompleteDatefromCourse = function (course, student_course) {
                    var _this = this;
                    var coString = "", date = '1970.1.1';
                    student_course.forEach(function (c) {
                        if (c.course_id === course.course_id && c.completedAt != null) {
                            date = new Date(c.completedAt) > new Date(date) ? c.completedAt : date;
                            coString = _this.getCompleteDate(date);
                        }
                    });
                    return coString == '' ? '' : coString;
                };
                Matrix.prototype.getCompleteDate = function (date) {
                    if (date == null || date == '1970.1.1')
                        return '';
                    var d = new Date(date), datestring = d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();
                    return datestring;
                };
                __decorate([
                    core_1.ViewChild('gridbasic'), 
                    __metadata('design:type', core_1.ElementRef)
                ], Matrix.prototype, "el", void 0);
                Matrix = __decorate([
                    core_1.Component({
                        selector: 'matrix',
                        templateUrl: '/components/matrix/matrix.html',
                        providers: [session_1.Session, tutor_1.TutorService],
                        directives: [router_1.ROUTER_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, tutor_1.TutorService, router_1.Router])
                ], Matrix);
                return Matrix;
            }());
            exports_1("Matrix", Matrix);
        }
    }
});
//# sourceMappingURL=matrix.js.map