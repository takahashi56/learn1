System.register(['angular2/core', '../../services/session', 'angular2/router', '../../services/authentication', 'angular2/common'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, authentication_1, common_1;
    var Resetpwd;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (authentication_1_1) {
                authentication_1 = authentication_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            Resetpwd = (function () {
                function Resetpwd(_session, _adminService, builder, _router) {
                    this._session = _session;
                    this._adminService = _adminService;
                    this.builder = builder;
                    this._router = _router;
                    this.submitAttempt = false;
                    this.matched = false;
                    this.show_class = '';
                    this.show_string = '';
                    this.length_6 = false;
                    var email = this._session.getItem('forget_user');
                    if (email == null) {
                        this._router.navigate(['Login']);
                    }
                    else {
                        this.password = new common_1.Control('', common_1.Validators.required);
                        this.verfiedPassword = new common_1.Control('', common_1.Validators.required);
                        this.show_class = "alert alert-info alert-dismissable";
                        this.show_string = "Enter your new password and log in again!";
                        this.length_6 = false;
                        this.ResetpwdForm = builder.group({
                            password: this.password,
                            verfiedPassword: this.verfiedPassword,
                        });
                    }
                }
                Resetpwd.prototype.matchedPassword = function (form) {
                    var password = form.password, verifiedpassword = form.verfiedPassword;
                    if (password == verifiedpassword) {
                        this.matched = true;
                        return true;
                    }
                    else {
                        this.matched = false;
                        return false;
                    }
                };
                Resetpwd.prototype.Resetpwd = function (form) {
                    var _this = this;
                    this.submitAttempt = true;
                    this.length_6 = false;
                    if (form.password.length < 6 || form.verfiedPassword.length < 6) {
                        this.show_class = "alert alert-danger alert-dismissable";
                        this.show_string = "The Password Must be At Least 6 characters!";
                        this.length_6 = true;
                        return;
                    }
                    if (this.matched == false) {
                        this.show_class = "alert alert-danger alert-dismissable";
                        this.show_string = "The Password Must be Matched!";
                        return;
                    }
                    if (this.ResetpwdForm.valid && this.matched) {
                        var email = this._session.getItem('forget_user');
                        this._adminService.resetpwd({ password: form.password, email: email }).subscribe(function (res) {
                            if (res.success) {
                                localStorage.clear();
                                _this._router.navigateByUrl("/login");
                            }
                        });
                    }
                };
                Resetpwd = __decorate([
                    core_1.Component({
                        selector: 'reset-pwd',
                        templateUrl: '/components/resetpwd/resetpwd.html',
                        providers: [session_1.Session, authentication_1.AuthService],
                        directives: [router_1.ROUTER_DIRECTIVES, common_1.FORM_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, authentication_1.AuthService, common_1.FormBuilder, router_1.Router])
                ], Resetpwd);
                return Resetpwd;
            }());
            exports_1("Resetpwd", Resetpwd);
        }
    }
});
//# sourceMappingURL=resetpwd.js.map