System.register(['angular2/core', '../../services/session', 'angular2/router', '../../services/authentication', '../../services/tutor'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, session_1, router_1, authentication_1, tutor_1;
    var Header;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_1_1) {
                session_1 = session_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (authentication_1_1) {
                authentication_1 = authentication_1_1;
            },
            function (tutor_1_1) {
                tutor_1 = tutor_1_1;
            }],
        execute: function() {
            Header = (function () {
                function Header(_session, router, _tutorService) {
                    this._session = _session;
                    this.router = router;
                    this._tutorService = _tutorService;
                    this.username = "";
                    this.creditcount = 0;
                    this.currentRole = Infinity;
                    this.show_credits = true;
                    this.show_not_save = false;
                    this.username = _session.getCurrentUsername();
                    this.currentRole = this._session.getCurrentRole();
                    var id = this._session.getCurrentId();
                    if (this.username == null || id == null) {
                        this.router.navigate(['Login']);
                    }
                    else if (this.currentRole == 1) {
                        this.creditcount = Number(this._session.getItem("creditcount"));
                    }
                }
                Header.prototype.ngOnInit = function () {
                    var _this = this;
                    setInterval(function () {
                        _this.updateCreditCount();
                    }, 1000);
                    // this._tutorService.event_emitter.subscribe((decrease)=>{
                    // 	this.creditcount = Number(this._session.getItem('creditcount'));
                    // })
                };
                Header.prototype.updateCreditCount = function () {
                    this.creditcount = Number(this._session.getItem('creditcount'));
                    this.username = this._session.getCurrentUsername();
                    this.show_credits = Number(this._session.getItem('subscribing')) == 0 ? true : false;
                };
                Header.prototype.doLogout = function () {
                    console.log('fdsa');
                    localStorage.clear();
                    this.router.navigate(['Login']);
                };
                Header.prototype.gotoCreditsTab = function () {
                    this.router.navigateByUrl('/home/tutor/main');
                    this._session.setItem('select_tutor_tab', 4);
                };
                Header.prototype.beforeLogout = function () {
                    this.show_not_save = false;
                    var flag = false, result = false;
                    console.log(JSON.parse(this._session.getItem('Course')));
                    if (JSON.parse(this._session.getItem('Course')) == null || JSON.parse(this._session.getItem('Course')) == [] || JSON.parse(this._session.getItem('Course')) == "" || JSON.parse(this._session.getItem('Course')) == undefined) {
                        console.log('a');
                        this.doLogout();
                        return;
                    }
                    else {
                        if (JSON.parse(this._session.getItem('Content')) == null || this._session.getItem('Content') == "" || this._session.getItem('Content') == undefined) {
                            flag = true;
                        }
                        else {
                            flag = false;
                        }
                    }
                    if (flag == false) {
                        console.log('b');
                        var contents = JSON.parse(this._session.getItem('Content'));
                        contents.forEach(function (content) {
                            if (content._id.length < 15) {
                                result = true;
                            }
                        });
                    }
                    else {
                        console.log('c');
                        var courseData = JSON.parse(this._session.getItem('Course')), lessons = courseData.lesson;
                        lessons.forEach(function (lesson) {
                            lesson.content.forEach(function (content) {
                                if (content._id.length < 15) {
                                    result = true;
                                }
                            });
                        });
                    }
                    console.log('d');
                    if (result) {
                        this.show_not_save = true;
                    }
                    else {
                        this.show_not_save = false;
                        this.doLogout();
                    }
                };
                Header = __decorate([
                    core_1.Component({
                        selector: 'my-header',
                        templateUrl: '/components/header/header.html',
                        providers: [session_1.Session, authentication_1.AuthService, tutor_1.TutorService],
                        directives: [router_1.ROUTER_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [session_1.Session, router_1.Router, tutor_1.TutorService])
                ], Header);
                return Header;
            }());
            exports_1("Header", Header);
        }
    }
});
//# sourceMappingURL=header.js.map