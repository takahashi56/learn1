System.register(['angular2/core', 'rxjs/add/operator/map', 'angular2/http'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1;
    var HEADER, StudentService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (_1) {},
            function (http_1_1) {
                http_1 = http_1_1;
            }],
        execute: function() {
            HEADER = {
                headers: new http_1.Headers({
                    'Content-Type': 'application/json'
                })
            };
            StudentService = (function () {
                function StudentService(_http) {
                    this._http = _http;
                    this.baseUrl = "/api/student/";
                }
                StudentService.prototype.updateCourse = function (id) {
                    return this._http.post(this.baseUrl + "updatescore", JSON.stringify({ student_id: id }), HEADER).map(function (res) { return res.json(); });
                };
                StudentService.prototype.getCourseListById = function (id) {
                    var data = {
                        student_id: id,
                    };
                    return this._http.post(this.baseUrl + "getcourselist", JSON.stringify(data), HEADER).map(function (res) { return res.json(); });
                };
                StudentService.prototype.getStudentInfo = function (id) {
                    var data = {
                        student_id: id,
                    };
                    return this._http.post(this.baseUrl + "getstudentinfo", JSON.stringify(data), HEADER).map(function (res) { return res.json(); });
                };
                StudentService.prototype.getLessonListById = function (id, student_id) {
                    var data = {
                        course_id: id,
                        student_id: student_id,
                    };
                    return this._http.post(this.baseUrl + "getlessonlist", JSON.stringify(data), HEADER).map(function (res) { return res.json(); });
                };
                StudentService.prototype.getContentsByLessonId = function (lesson_id) {
                    var data = {
                        lesson_id: lesson_id
                    };
                    return this._http.post(this.baseUrl + 'getcontentslist', JSON.stringify(data), HEADER).map(function (res) { return res.json(); });
                };
                StudentService.prototype.setScoreForLesson = function (data) {
                    return this._http.post(this.baseUrl + 'setscoreforlesson', JSON.stringify(data), HEADER).map(function (res) { return res.json(); });
                };
                StudentService.prototype.setCourseScoreWithStudent = function (data) {
                    return this._http.post(this.baseUrl + 'setcoursescorewithstudent', JSON.stringify(data), HEADER).map(function (res) { return res.json(); });
                };
                StudentService.prototype.getScoreListByCourse = function (data) {
                    return this._http.post(this.baseUrl + 'getscorelist', JSON.stringify(data), HEADER).map(function (res) { return res.json(); });
                };
                StudentService.prototype.resetCourse = function (student_id, course_id) {
                    return this._http.post(this.baseUrl + 'resetcourse', JSON.stringify({ student_id: student_id, course_id: course_id }), HEADER).map(function (res) { return res.json(); });
                };
                StudentService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], StudentService);
                return StudentService;
            }());
            exports_1("StudentService", StudentService);
        }
    }
});
//# sourceMappingURL=student.js.map