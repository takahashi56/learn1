System.register(['angular2/core', '../services/config'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, config_1;
    var Session;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (config_1_1) {
                config_1 = config_1_1;
            }],
        execute: function() {
            Session = (function () {
                function Session(_config) {
                    this._config = _config;
                    this.lock = new Auth0Lock(this._config.getClientId(), this._config.getDomain());
                }
                Session.prototype.login = function () {
                    this.lock.show(function (error, profile, id_token) {
                        if (error) {
                            console.error(error);
                        }
                        // We get a profile object for the user from Auth0
                        localStorage.setItem('profile', JSON.stringify(profile));
                        // We also get the user's JWT
                        localStorage.setItem('id_token', id_token);
                    });
                };
                Session.prototype.logout = function () {
                    // To log out, we just need to remove
                    // the user's profile and token
                    localStorage.removeItem('profile');
                    localStorage.removeItem('id_token');
                };
                /*
                 * role = 0 : admin
                 * role = 1 : tutor
                 * role = 3 : student
                */
                Session.prototype.setItem = function (item, data) {
                    localStorage.setItem(item, data);
                };
                Session.prototype.getItem = function (item) {
                    return localStorage.getItem(item);
                };
                Session.prototype.setUser = function (username, role, id) {
                    localStorage.setItem('username', username);
                    localStorage.setItem('role', role);
                    localStorage.setItem('id', id);
                };
                Session.prototype.getCurrentId = function () {
                    return localStorage.getItem('id');
                };
                Session.prototype.getCurrentUser = function () {
                    var username = localStorage.getItem('username'), role = localStorage.getItem('role');
                    return {
                        username: username,
                        role: role,
                    };
                };
                Session.prototype.getCurrentUsername = function () {
                    return localStorage.getItem('username');
                };
                Session.prototype.getCurrentRole = function () {
                    return parseInt(localStorage.getItem('role'));
                };
                Session = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [config_1.AppConfig])
                ], Session);
                return Session;
            }());
            exports_1("Session", Session);
        }
    }
});
//# sourceMappingURL=session.js.map