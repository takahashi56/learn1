'use strict';
//#if FALSE
var a;
//#else
var b;
//#endif
