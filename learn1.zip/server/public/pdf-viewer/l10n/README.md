Most of the files in this folder (except for the `en-US` folder and the
`metadata.inc` files) have been imported from the Firefox Aurora branch,
which is located at https://mxr.mozilla.org/l10n-mozilla-aurora/source.
Some of the files are licensed under the MPL license. You can obtain a
copy of the license at http://mozilla.org/MPL/2.0.
